package org.cap.demo;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
	
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args)
	{
		String empId;
		System.out.println("Enter Employee Id");
		empId = scanner.next();
		
		/*if(empId.matches("\\d{5}_(FS|TS|IN)")) {
			System.out.println("Employee matched");
		}
			else
			{
				System.out.println("please try");
			}*/
		
		Pattern pattern = Pattern.compile("\\d{5}_(FS|TS|IN)");
		Matcher matcher = pattern.matcher(empId);
		
		System.out.println(matcher.find());
	}
}
