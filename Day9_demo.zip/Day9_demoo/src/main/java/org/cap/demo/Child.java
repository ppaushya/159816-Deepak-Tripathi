package org.cap.demo;

import java.io.FileNotFoundException;

public class Child extends Parent {
	
	public void print() throws FileNotFoundException, InterruptedException{
		System.out.println("THumbs up");
	}

}
