package org.cap.demo;

public class Calculation {
	public void method() throws NullPointerException,NumberFormatException
	{
		Integer num1 =100;
		Integer num2 =null;
		Integer ans =null;
		
				ans=num1+num2;
				System.out.println(ans);	
				
				
				
						String num="8s";
						int result =ans/Integer.parseInt(num);
						System.out.println("Answer:" + result);
					
				
				
					System.out.println("InnerTryBlockOver");
		
		System.out.println("Answer:" + ans);
	}
	public static void main(String[] args) {
		
		Calculation calculation = new Calculation();
		try {
			calculation.method();
		}
		catch(NullPointerException|NumberFormatException e)
		{
			e.printStackTrace();
		}
	}

}
