package org.cap.demo;

import java.io.FileInputStream;


public class TestClass {

	public static void main(String[] args)
	{
	//	File file = new File("C:\\sample.data.txt");
		//FileInputStream inputStream = new FileInputStream(file);
	}
}
