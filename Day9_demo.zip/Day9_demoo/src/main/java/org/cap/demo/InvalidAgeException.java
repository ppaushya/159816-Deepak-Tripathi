package org.cap.demo;

public class InvalidAgeException extends Throwable{
	
	public InvalidAgeException(String msg)
	{
		super(msg);
	}
	
	public InvalidAgeException()
	{
		
	}
	
	/*public String getMessage()
	{
		return "Sorry!Invalid Age";
	}*/

}
