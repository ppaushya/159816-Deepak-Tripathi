package org.cap.demo;

public class CheckException {
	
	public static void main(String[] args)
	{
		int num1 = 100;
		String num2 = "12s";
		
		int result = 0;
		try {
		result = num1/Integer.parseInt(num2);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Finally Block Statement");
			
		}
	
		/*catch(NumberFormatException ns)
		{
			System.out.println(ns.getMessage());
			ns.printStackTrace();
		}
		System.out.println("Result:" + result);*/
	}

}
