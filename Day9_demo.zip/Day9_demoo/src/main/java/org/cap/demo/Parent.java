package org.cap.demo;

import java.io.FileNotFoundException;

public class Parent {
	
	public void print() throws NumberFormatException, NullPointerException,FileNotFoundException, InterruptedException
	{
		
	}

}
