package org.cap.demo;

public class TestMain {
	
	public static void main(String[] args) throws InvalidAgeException
	{
		int age = 12;
		//try {
		//if(age<18)
		throw new InvalidAgeException("Sorry!age");
		//}
		/*catch(InvalidAgeException e)
		{
			System.out.println(e.getLocalizedMessage());
		}*/
	}

}
