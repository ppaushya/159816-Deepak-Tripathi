package org.cap.demo;

public class Demo {
	public static void main(String[] args) throws ArithmeticException
	{
		Integer num1 =100;
		Integer num2 =null;
		Integer ans =null;
		try {
				ans=num1+num2;
				System.out.println(ans);	
				
				
					try {
						String num="8s";
						int result =ans/Integer.parseInt(num);
						System.out.println("Answer:" + result);
					}
				
					catch(NullPointerException|NumberFormatException  e)
					{
						e.printStackTrace();
					}
					System.out.println("InnerTryBlockOver");
			 }      
		            catch(NullPointerException|NumberFormatException e)
						{
							System.out.println(e.getMessage());
						}
		
		System.out.println("Answer:" + ans);
	
	}
}
