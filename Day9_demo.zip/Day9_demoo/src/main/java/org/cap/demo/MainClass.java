package org.cap.demo;

import java.io.FileNotFoundException;

public class MainClass {
	
	public static void main(String[] args) throws FileNotFoundException, InterruptedException
	{
		
		Child child = new Child();
		try {
		child.print();
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}

}
