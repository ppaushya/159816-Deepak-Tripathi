package org.cap.assignment;

import java.util.Scanner;

public class RegularExpression {
	
	static Scanner KB = new Scanner(System.in);
	public static void main(String[] args)
	{
		String CustomerId;
		String name;
		String Address;
		String emailId;
		String mobileNo;
		String AccountNo;
		//Date openingDate;
		System.out.println("Enter Customer Id: ");
		CustomerId=KB.next();
		if(CustomerId.matches("\\d{6,10}"))
		{
			System.out.println("Employee matched");
		}
		else
		{
			System.out.println("Please again try");
		}
		
		System.out.println("Enter Name: ");
		name=KB.next();
		if(name.matches("[a-z]"))
		{
			System.out.println("Employee matched");
		}
		else
		{
			System.out.println("Please again try");
		}
		
		System.out.println("Enter Address: ");
		Address=KB.next();
		if(Address.matches("\\d [a-z]"))
		{
			System.out.println("Employee matched");
		}
		else
		{
			System.out.println("Please again try");
		}
		
		System.out.println("Enter Mobile Number: ");
		mobileNo=KB.next();
		if(mobileNo.matches("\\d{10}"))
		{
			System.out.println("Employee matched");
		}
		else
		{
			System.out.println("Please again try");
		}
		
		System.out.println("Enter Email Id: ");
		AccountNo=KB.next();
		if(AccountNo.matches("^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$"))
		{
			System.out.println("Employee matched");
		}
		else
		{
			System.out.println("Please again try");
		}
		
	}

}
