package org.cap.demo;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;


public class ArrayListDemo {

	public static void main(String[] args) {
		//ArrayList<String> Lst = new ArrayList<>();
		Vector<String> Lst = new Vector<>();
		
		Lst.add("Tom");
		Lst.add("jerry");
		Lst.add("mon");
		Lst.add("Tue");
		Lst.add(null);
		Lst.add("Tom");
		
		///Iterator is always pointing towards the first element 
		///List Iterator can point to both the address forward and backward data simultaneosly
		
		for(String str:Lst)
		{
			System.out.print(str + ",");
		}
		System.out.println();
		
		Iterator<String> iterator = Lst.iterator();
		
		while(iterator.hasNext())
		{
			String str = iterator.next();
			System.out.println(str + " ,");
		}
		System.out.println();
		
		ListIterator<String> lstIterator = Lst.listIterator();
		
		while(lstIterator.hasNext())
		{
			String s = lstIterator.next();
			System.out.print(s + "-->");
		}
		
		System.out.println();
		
		while(lstIterator.hasPrevious())
		{
			String s = lstIterator.previous();
			System.out.print(s + "-->");
		}
		
		System.out.println();
		
		Enumeration<String> enumeration = Lst.elements();
		while(enumeration.hasMoreElements())
		{
			String s = enumeration.nextElement();
			System.out.print(s + "-->");
		}
		
		System.out.println();
		
		
	}
			/*List will extend one more interface called as list interface, all list set and queue can use the iterator 
			 * Array list can be used for the list iterator*/
			/*Via List Iterator we can traverse three forms that include arrayList, LinkedList, Vector*/	
			/*Vector is thread safe and it can be called by enumerated data types*/
			/*List iterator gives you chance for modify new employees whereas iterator just gives you only chance to remove the values*/
			/*Lock over the container and we can remove and set method*/
			/*ArrayList performance wise slow and vector performance wise high, vector can come with initial capacity and incremental capacity whereas the 
			 * arrrayList has no incremental capacity and vector can be enumerated whereas arrayList cannot be enumerantal, where vector can be made collection there is synchronised workm,
			 * linked List we can do frequent manipulation so we can go to the linkedList, vector is legacy API*/
			 
}
