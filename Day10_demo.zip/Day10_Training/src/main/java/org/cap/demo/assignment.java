package org.cap.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.Vector;

public class assignment {

		@SuppressWarnings("unlikely-arg-type")
		public static void main(String args[]) 
	    { 
	  
	        // create an empty array list1 with initial  
	        // capacity as 5 
	        ArrayList<Integer> arrlist1 =  
	                           new ArrayList<Integer>(5); 
	  
	      
	        arrlist1.add(12); 
	        arrlist1.add(20); 
	        arrlist1.add(45); 
	        arrlist1.add(56); 
	  

	        System.out.println("Printing list1:"); 
	        for (Integer number : arrlist1)  
	            System.out.println("Number = " + number);         
	  

	        ArrayList<Integer> arrlist2 =  
	                             new ArrayList<Integer>(5); 
	  

	        arrlist2.add(25); 
	        arrlist2.add(30); 
	        arrlist2.add(31); 
	        arrlist2.add(35); 
	  
	  
	        System.out.println("Printing list2:"); 
	        for (Integer number : arrlist2)  
	            System.out.println("Number = " + number);         
	 
	        arrlist1.addAll(arrlist2); 
	  
	        System.out.println("Printing all the elements"); 
	        for (Integer number : arrlist1)  
	            System.out.println("Number = " + number); 
	        
	        int retval = arrlist1.size();
	        System.out.println("Size of list = " + retval);
	        
	        boolean retval1 = arrlist1.contains(10); 
	        
	        if (retval1 == true) {
	           System.out.println("element 10 is contained in the list");
	        } else {
	           System.out.println("element 10 is not contained in the list");
	        }
	        int retval2 = arrlist2.size();
	        System.out.println("List consists of "+ retval2 +" elements");
	           
	        System.out.println("Performing clear operation !!");
	        arrlist2.clear();
	        retval = arrlist2.size();
	        System.out.println("Now, list consists of "+ retval2 +" elements");
	        @SuppressWarnings("rawtypes")
			ArrayList arrlist3 = (ArrayList) arrlist1.clone();
	        for (int i = 0; i < arrlist2.size(); i++) {
	            System.out.print(arrlist3.get(i));
	         }
	        arrlist1.addAll(2, arrlist2);
	        
	        System.out.println("Printing all the elements");


	        for (Integer number : arrlist1) {
	           System.out.println("Number = " + number);
	        }
	           arrlist1.ensureCapacity(15);

	           for (Integer number1 : arrlist1) {
	              System.out.println("Number = " + number1);
	           }
	           @SuppressWarnings("unlikely-arg-type")
			int retval4 = arrlist1.indexOf("20");
	           System.out.println("The element E is at index " + retval4);
	           
	           @SuppressWarnings("unlikely-arg-type")
			int retval5 = arrlist1.lastIndexOf("20");
	           System.out.println("The last occurrence of E is at index " + retval5);
	           
	           arrlist1.remove(2);

	           System.out.println("Now, Size of list: " + arrlist1.size());
	           
	           for (Integer value : arrlist1) {
	               System.out.println("Value = " + value);
	            }  
	            
	            
	            arrlist1.remove("20");

	            System.out.println("Now, Size of list: " + arrlist1.size());
	            
	      
	            for (Integer value : arrlist1) {
	               System.out.println("Value = " + value);
	            }  
	            arrlist1.set(2,55);
	            

	            System.out.println("Printing new list:");
	            for (Integer number : arrlist1) {
	               System.out.println("Number = " + number);
	            } 
	            
	            Object[] ob = arrlist1.toArray();

	            System.out.println("Printing elements from first to last:"); 
	            for (Object value : ob) {
	               System.out.println("Number = " + value);
	            }
	
	            arrlist2.trimToSize();

	           
	            for (Integer number : arrlist2) {
	               System.out.println("Number = " + number);
	            }
	            
	            Spliterator<Integer> namesSpliterator = arrlist2.spliterator();
	    		
	        	
	        	namesSpliterator.forEachRemaining(System.out::println);
	        	
	        	 //System.out.println("is arr1 equals to arr2 : " + Arrays.equals(arrlist1, arrlist2)); 
	        	
	            Vector<Integer> vec_tor = new Vector<Integer>(); 
	      
	            
	            vec_tor.add(5); 
	            vec_tor.add(1); 
	            vec_tor.add(50); 
	            vec_tor.add(10); 
	            vec_tor.add(20); 
	            vec_tor.add(6); 
	            vec_tor.add(20); 
	            vec_tor.add(18); 
	            vec_tor.add(9); 
	            vec_tor.add(30); 
	      
	            System.out.println("The Vector is: " + vec_tor); 
	      
	         
	            List<Integer> sub_list = new ArrayList<Integer>(); 
	      
	        
	            sub_list = vec_tor.subList(2, 5); 
	      
	            
	            System.out.println("The resultant values "  + "within the sub list: " + sub_list); 
	    }
		
		//Thread safe but it would also very slow.
		//
}
