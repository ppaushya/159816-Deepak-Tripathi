package org.cap.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class CollectionDemo {
	
	public static void main(String[] args)
	{
		ArrayList list = new ArrayList<>();
		List Lst = new ArrayList<>();
		
		Collection lst1 = new ArrayList();
		Iterable lst2 = new ArrayList();
		
		//Lang package is default package..
		
		//If I declare the instance variable for the interface 
		
		Lst.add(3);
		Lst.add("Tom");
		Lst.add(45.89);
		Lst.add(45.89);
		Lst.add(null);
		Lst.add(23423);
		Lst.add(23423223);
		Lst.add(null);
		Lst.add(new Object());
		
		System.out.println(Lst);
		
		
		System.out.println(Lst.get(3));
		
	}

}
