package org.cap.demo;

import java.time.LocalDate;

public class Account {
	
	private long accountNo;
	private LocalDate openingDate;
	private double openingBalance;
	public Account() {
		
	}
	
	
	public Account(long accountNo,  LocalDate openingDate, double openingBalance) {
		super();
		this.accountNo = accountNo;
		this.openingDate = openingDate;
		this.openingBalance = openingBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	
	public LocalDate getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo  + ", openingDate=" + openingDate
				+ ", openingBalance=" + openingBalance + "]";
	}
	

}

