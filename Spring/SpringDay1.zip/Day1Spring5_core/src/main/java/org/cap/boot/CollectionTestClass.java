package org.cap.boot;

import org.cap.model.CollectionDemo;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CollectionTestClass {
	
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("collectionDemo.xml");
		CollectionDemo coldem =(CollectionDemo)context.getBean("myDemo");

		System.out.println(coldem);
		context.registerShutdownHook();




	}

}
