package org.cap.boot;

import org.cap.config.Myconfig;
import org.cap.model.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class ImportTestClass {

	public static void main(String[] args)
	{
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(Myconfig.class);
		String string = context.getBean(String.class);
		Employee employee = context.getBean(Employee.class);

		System.out.println(string);
		System.out.println(employee);

	}
}
