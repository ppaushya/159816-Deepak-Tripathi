package org.cap.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.cap.model.Employee;
import org.cap.model.Address;

@Configuration
public class Config {
	
	@Bean
	//@Scope("prototype")
	public Employee Employee()
	{
		//return new Employee(101, "Deepak", 84556);
		Employee emp = new Employee();
		emp.setEmployeeName("Jem");
		emp.setSalary(12000);
		return emp;
	}
	
	@Bean
	@Qualifier("add1")
	public Address Address1()
	{
		return new Address("central", "chennai");
	}
	
	@Bean
	@Qualifier("add2")
	public Address Address()
	{
		return new Address("North", "Prayagraj");
	}
	

}
