package org.cap.controller;

import java.time.LocalDate;
import java.util.Date;

import javax.validation.Valid;

import org.cap.model.Register;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RegisterController {

	@Autowired
	private IRegisterService registerService;
	//@RequestMapping(value="/registerForm",method=RequestMethod.POST)
	@PostMapping("/registerForm")
	public String registerDetails(
			@Valid @ModelAttribute("register")Register register,
				BindingResult result) {
		
		if(result.hasErrors())
			return "register";
		
		
		registerService.isValidRegister(register);
		return "success";
		
		
	}
}
