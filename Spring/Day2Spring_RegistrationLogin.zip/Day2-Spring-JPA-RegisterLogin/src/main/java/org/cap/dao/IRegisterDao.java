package org.cap.dao;

import org.cap.model.Register;

public interface IRegisterDao {

	
	public boolean isValidRegister(Register register);
}
