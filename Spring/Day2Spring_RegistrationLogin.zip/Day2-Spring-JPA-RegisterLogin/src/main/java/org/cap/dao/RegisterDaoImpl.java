package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.cap.model.LoginPojo;
import org.cap.model.Register;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("registerDao")
@Transactional
public class RegisterDaoImpl implements IRegisterDao{
	
	@PersistenceContext
	private EntityManager em;

	@Override
	
	public boolean isValidRegister(Register register) {
		
		String sql="insert into Register (firstName, lastName, address, city, gender, qualification, dateOfBirth, email, password, confirmpassword, regFees) values (?,?,?,?,?,?,?,?,?,?,?)";
		Query query= em.createNativeQuery(sql);
		
		query.setParameter(1, register.getFirstName());
		query.setParameter(2, register.getLastName());
		query.setParameter(3, register.getAddress());
		query.setParameter(4, register.getCity());
		query.setParameter(5, register.getGender());
		query.setParameter(6, register.getQualification());
		query.setParameter(7, register.getDateOfBirth());
		query.setParameter(8, register.getEmail());
		query.setParameter(9, register.getPassword());
		query.setParameter(10, register.getConfirmpassword());
		query.setParameter(11, register.getRegFees());
		
		
		int n = query.executeUpdate();
		
		/*String sql1 = "insert into LoginPojo (userName,userPassword) values (?,?)";
		Query query1= em.createNativeQuery(sql1);
		query1.setParameter(1, register.getFirstName());
		query1.setParameter(2, register.getConfirmpassword());
		
		query1.executeUpdate();
		*/
		if(n >0)
			return true;
		
		return false;
	}

}
