package org.cap.dao;

import org.cap.model.LoginPojo;

public interface ILoginDao {

	
	public boolean isValidLogin(LoginPojo loginPojo);
}
