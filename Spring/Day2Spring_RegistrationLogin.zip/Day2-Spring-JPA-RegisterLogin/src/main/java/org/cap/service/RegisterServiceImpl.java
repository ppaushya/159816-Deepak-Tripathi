package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.IRegisterDao;
import org.cap.model.LoginPojo;
import org.cap.model.Register;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("registerService")
public class RegisterServiceImpl implements IRegisterService {
	
	@Autowired
	private IRegisterDao registerDao;

	@Override
	public boolean isValidRegister(Register register) {
		return registerDao.isValidRegister(register);
	}

}
