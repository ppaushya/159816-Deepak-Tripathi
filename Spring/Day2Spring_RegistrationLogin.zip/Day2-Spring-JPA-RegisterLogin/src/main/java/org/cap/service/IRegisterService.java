package org.cap.service;

import org.cap.model.LoginPojo;
import org.cap.model.Register;

public interface IRegisterService {

	public boolean isValidRegister(Register register) ;
}
