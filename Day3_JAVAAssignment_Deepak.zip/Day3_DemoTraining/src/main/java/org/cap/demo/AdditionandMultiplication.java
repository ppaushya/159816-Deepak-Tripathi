package org.cap.demo;

import java.util.Scanner;

public class AdditionandMultiplication {

	
	
	int row;
	int col;
	
	public static void main(String[] args)
	{
		int[][] arr1=new int[3][3];
		int[][] arr3=new int[3][3];
		int[][] arr2=new int[3][3];
		int[][] arr4=new int[3][3];
		MinimumArray two = new MinimumArray();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Rows");
		two.row = scanner.nextInt();
		System.out.println("Enter Columns");
		two.col = scanner.nextInt();
		if(two.row == two.col)
		{
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr1[i][j]=scanner.nextInt();
				}
				System.out.println();
			}
			
			System.out.println("\n");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr2[i][j]=scanner.nextInt();
				}
				System.out.println();
			}
		    
			System.out.println("\n");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr3[i][j]=arr1[i][j]+arr2[i][j];
				}
				System.out.println();
			}
			
			System.out.println("\n");
			System.out.println("Addition of Matrices");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					
					System.out.print(arr3[i][j]+ " ");
				}
				System.out.println();
			}
			
			System.out.println("\n");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					 for (int k = 0; k < two.row; k++) {
		                    arr4[i][j] += arr1[i][k] * arr2[k][j];
		                }
				}
				System.out.println();
			}
			
			System.out.println("\n");
			System.out.println("Multiplication of Matrices");
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					
					System.out.print(arr4[i][j]+" ");
				}
				System.out.println();
			}
			
		}
		else
		{
			System.out.println("Not Correct Matrix");
			System.exit(0);
		}
	}
}
