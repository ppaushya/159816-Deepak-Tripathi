package PersonalDetails;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	private WebDriver webdriver;
	private WebElement element;

	@Before
	public void setUp() {

		String exePath = "C:\\Users\\deeptrip\\Downloads\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);

		webdriver = new ChromeDriver();

	}


	@Given("^Customer Registration Page$")
	public void customer_Registration_Page() throws Throwable {
		webdriver.get("file:///C:/Users/deeptrip/Desktop/Conferencebooking/ConferenceRegistartion.html");

		String actualTitle = webdriver.getTitle();
		element = webdriver.findElement(By.xpath("/html/body/h4"));
		String heading = element.getText();
		if(actualTitle.equals("Conference Registration") && heading.equals("Personal Details"))
		{
			System.out.println("true");
			webdriver.close();
			webdriver.quit();
		}
		else
		{
			System.out.println("False");

		}



	}

	@When("^Validate Details$")
	public void validate_Details() throws Throwable {
		
		/*Alert alert=webdriver.switchTo().alert();
		int j =1;
		boolean flag = true;
		
		for(j=1;j<=10; j++)
		{
			switch(j)
			{
			  case 1:	while(flag) {
				  if(alert.getText().compareTo("Please fill the First Name")==0)
				  {
				  webdriver.switchTo().alert().accept();
				  webdriver.get("http://localhost:8080/Conferencebooking/");
				  webdriver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("sid");
				  webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
				  alert=webdriver.switchTo().alert();
				  if(alert.getText().compareTo("Please fill the Last Name")==0)
				  {
				  webdriver.switchTo().alert().accept();
				              webdriver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("jerry");
				              webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
				      alert=webdriver.switchTo().alert();
				  }
				  }
			  						}
			}
		}*/

		webdriver.findElement(By.name("txtFN")).sendKeys("Deepak");
		webdriver.findElement(By.name("txtLN")).sendKeys("Tripathi");
		webdriver.findElement(By.name("Email")).sendKeys("dk@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("8318746896");
		Select select = new Select(webdriver.findElement(By.name("size")));
		select.selectByValue("one");
		webdriver.findElement(By.name("Address")).sendKeys("123 Building");
		webdriver.findElement(By.name("Address2")).sendKeys("Chttipuniya");
		Select select1 = new Select(webdriver.findElement(By.name("city")));
		select1.selectByValue("Chennai");


		Select select11 = new Select(webdriver.findElement(By.name("state")));
		select11.selectByValue("Tamilnadu");



		List<WebElement> GenderList = webdriver.findElements(By.name("memberStatus"));
		String Value;
		for(int i=0;i < GenderList.size();i++){
			Value = (GenderList.get(i)).getAttribute("value");
			if(Value.equals("member"))
				( GenderList.get(i)).click();
		}
		/*String firstName = element.getText();
		if(firstName.isEmpty())
		{
			webdriver.findElement(By.linkText("Next")).click();
			Alert simpleAlert = webdriver.switchTo().alert();
			String alertText = simpleAlert.getText();
			System.out.println("Alert text is " + alertText);
			simpleAlert.accept();
		}*/
		
			


	}

	@Then("^Navigate to payment page$")
	public void navigate_to_main_page() throws Throwable {

		webdriver.navigate().to("file:///C:/Users/deeptrip/Desktop/Conferencebooking/PaymentDetails.html");
	}

	@Then("^Validate Payment Details$")
	public void validate_Payment_Details() throws Throwable {


	}

	@Then("^Registration Successful$")
	public void registration_Successful() throws Throwable {


	}
}

