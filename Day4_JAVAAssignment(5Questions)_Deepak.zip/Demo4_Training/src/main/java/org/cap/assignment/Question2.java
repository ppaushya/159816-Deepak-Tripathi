package org.cap.assignment;

import java.util.Scanner;

public class Question2 {
	
	public void Alphabetsoup(String str)
	{
		char t[]=new char[str.length()];
		
		int i,j;
		
		char temp;
		
		for(i=0;i<str.length();i++)
		{
			t[i]=str.charAt(i);
		}
		
		
		for(i=0;i<str.length();i++)
		{
			for(j=i+1;j<str.length();j++)
			{
				if(t[i]>t[j])
				{
					temp=t[i];
					t[i]=t[j];
					t[j]=temp;
				}
			}
		}
		
		
		for(i=0;i<str.length();i++)
		{
			System.out.println(t[i]);
		}
	}
	
	
	public static void main(String[] args) {
		
		
		Scanner s=new Scanner(System.in);
		String str;
		System.out.println("Enter the array:");
		str=s.next();
		Question2  obj=new Question2 ();
		
		obj.Alphabetsoup(str);
		

	}

}
