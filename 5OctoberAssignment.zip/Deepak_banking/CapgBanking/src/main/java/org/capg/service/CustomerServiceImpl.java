package org.capg.service;

import java.time.LocalDate;
import java.util.List;

import org.capg.dao.CustomerDaoImpl;
import org.capg.dao.ICustomerDao;
import org.capg.model.Customer;

public class CustomerServiceImpl implements ICustomerService{
	
	private ICustomerDao customerDao=new CustomerDaoImpl();
	
	

	@Override
	public void createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
					customerDao.createCustomer(customer);
		}
		
		
	}
	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobile().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.getAllCustomers();
	}

}
