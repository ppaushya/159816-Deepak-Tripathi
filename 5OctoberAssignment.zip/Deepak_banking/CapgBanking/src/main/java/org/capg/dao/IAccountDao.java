package org.capg.dao;

import java.util.List;
import java.util.Set;

import org.capg.model.Account;

public interface IAccountDao {

	public Set<Account> getAllAccounts();
	public void createAccount(Account account);
}
