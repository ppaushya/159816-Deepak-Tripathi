package org.capg.service;

import java.util.List;
import java.util.Set;

import org.capg.dao.AccountDaoImpl;
import org.capg.dao.CustomerDaoImpl;
import org.capg.dao.IAccountDao;
import org.capg.dao.ICustomerDao;
import org.capg.model.Account;

public class AccountServiceImpl implements IAccountService {

	private IAccountDao accountDao=new AccountDaoImpl();
	
	@Override
	public void createAccount(Account account) {
		accountDao.createAccount(account);
		
	}

	@Override
	public Set<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accountDao.getAllAccounts();
	}

}
