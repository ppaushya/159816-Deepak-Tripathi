package org.xyz.service;

import org.xyz.model.LoginBean;

public interface ILoginService {

	public boolean isValidLogin(LoginBean loginBean);
}
