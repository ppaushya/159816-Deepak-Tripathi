package org.xyz.dao;

import org.xyz.model.CustomerBean;

public interface IRegisterDao {

	public boolean registerCustomer(CustomerBean customerBean);
}
