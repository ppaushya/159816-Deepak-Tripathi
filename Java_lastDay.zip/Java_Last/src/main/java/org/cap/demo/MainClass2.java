package org.cap.demo;

public class MainClass2 {
	
	public static void main(String[] args)
	{
		ThreadDemo runnable = new ThreadDemo();
		
		Thread t1 = new Thread(runnable,"Capgemini");

		Thread t2 = new Thread(runnable,"Kanbay");

		Thread t3 = new Thread(runnable," ");
	
		
		t1.start();
		
		
		
		t2.start();
		
		
		try {
				t2.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 t3.setDaemon(true);  
	        t3.start(); 
		
	}

}
