package org.cap.demo;

public class MainClassTable {
	
	public static void main(String[] args)
	{
		ThreadTable runnable = new ThreadTable();
		Thread t1 = new Thread(runnable," ");
		t1.start();
	}

}
