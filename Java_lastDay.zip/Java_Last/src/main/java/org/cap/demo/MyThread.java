package org.cap.demo;

public class MyThread extends Thread {
	
	public MyThread(String string) {
		super(string);
	}
	
	@Override
	public void run()
	{
		System.out.println(getName() + "--->" + "Thread Started..........");
	}
	
	public MyThread()
	{
		
	}
	
	
}
 