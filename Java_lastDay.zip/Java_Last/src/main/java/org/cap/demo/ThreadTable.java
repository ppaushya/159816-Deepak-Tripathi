package org.cap.demo;

public class ThreadTable implements Runnable{

	@Override
	public void run() {
		
		printTable();
		
	}
	
	synchronized public void  printTable()
	{

		int a=13;
		int b=15;
		int c=21;
		

		System.out.println("========================TABLE CREATION=================================");
		for(int i=1; i<=10;i++)
		{
			System.out.println("                       "+Thread.currentThread().getName() + i + " * " + a +"-->"+i*a);
			
		}
		System.out.println("========================TABLE CREATION=================================");
		for(int i=1; i<=10;i++)
		{
			System.out.println("                       "+Thread.currentThread().getName() + i + " * " + b +"-->"+i*b);
		}
		System.out.println("========================TABLE CREATION=================================");
		for(int i=1; i<=10;i++)
		{
			System.out.println("                        "+Thread.currentThread().getName() + i + " * " + c +"-->"+i*c);
		}
	}

}
