package org.cap.demo;

public class MainSynchr implements Runnable{
	
	
	
	Thread t1 = new Thread();
	@Override
	public void run()
	{
		
	}
	
	
	public static void main(String[] args)
	{
		
	}

	
}
