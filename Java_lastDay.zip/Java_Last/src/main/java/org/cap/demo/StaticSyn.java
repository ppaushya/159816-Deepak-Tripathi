package org.cap.demo;

public class StaticSyn {
	
	static int count;
	
	public static void staticMethod(){
		count++;
		for(int i=0;i<=100;i++)
			System.out.println(Thread.currentThread().getName() + "-->"+i);
		
		System.out.println("Count:" + count);
	}
	
	public void show()
	{
		
	}
}
