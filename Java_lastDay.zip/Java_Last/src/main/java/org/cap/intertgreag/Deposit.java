package org.cap.intertgreag;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Deposit implements Runnable
{
    private final LinkedList < Integer > sharedQ;
    private int maxSize;
     
    public Deposit(LinkedList < Integer > sharedQ, int maxSize)
    {
        this.sharedQ = sharedQ;
        this.maxSize = maxSize;
    }
     
    @Override
    public void run(){
         
        while(true)
        {
            synchronized (sharedQ) {
                while(sharedQ.size()==maxSize)
                {
                    try
                    {
                        System.out.println("Queue is full");
                        sharedQ.wait();
                    }
                    catch(InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                     
                }
                Random random = new Random(); 
                int number = random.nextInt(100);
                System.out.println("Depsoit " + number);
                sharedQ.add(number);
                sharedQ.notify();
                 
            }
             
        }
    }
}