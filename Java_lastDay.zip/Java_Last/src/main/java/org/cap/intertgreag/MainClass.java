package org.cap.intertgreag;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
 
 

public class MainClass {
 
    public static void main(String[] args) throws InterruptedException {
         
         
        final LinkedList < Integer > sharedQ = new LinkedList < Integer >();
         
        Thread consumerThread = new Thread(new Withdraw(sharedQ, 4), "Withdraw");
        Thread producerThread = new Thread(new Deposit(sharedQ, 4), "Deposit");
         
        producerThread.start();
        consumerThread.start();
         
         
    }
}
 
