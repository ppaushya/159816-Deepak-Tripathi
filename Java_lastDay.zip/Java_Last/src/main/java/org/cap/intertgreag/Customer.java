package org.cap.intertgreag;


public class Customer {

	private int amount;
	
	public Customer(int amount) {
		// TODO Auto-generated constructor stub
		this.amount=amount;
	}


	public synchronized void deposit(int moneydep)
	{
		this.amount=(this.amount)+moneydep;
	   System.out.println("my current updated balance is "+((this.amount)));	
	   notify();
	}
	
	
	public synchronized void withdrawal(int moneywtd)
	{
		System.out.println();
		if(this.amount<moneywtd)
		{
			try {
				System.out.println("thread is waiting");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		}
		else
			this.amount=(this.amount)-moneywtd;
		{ System.out.println("my current update balance is "+(this.amount-moneywtd));	

		}
	}
	
}
	

