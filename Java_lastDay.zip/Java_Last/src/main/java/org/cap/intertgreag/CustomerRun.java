package org.cap.intertgreag;

public class CustomerRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Customer obj=new Customer(50);
 
 Thread t1=new Thread()
		 {
	        public void run()
	        {
	        	obj.withdrawal(200);
	        }
		 };
 t1.start();
 
 

t1.setPriority(2);
 System.out.println(t1.getPriority());
 
 Thread t2=new Thread()
 {
    public void run()
    {
    	obj.deposit(200);
    }
 };
t2.start();
	}


	
}
