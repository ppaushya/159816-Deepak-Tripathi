package org.lib.util;


public class Utility {

	
	public static boolean isvaliduser(String userName)
	{
		
		//Validating Username
		 if(userName.matches("[a-zA-Z]+"))
		 {
			 
				 return true;
			 
		 }
		 return false;
	}
}

