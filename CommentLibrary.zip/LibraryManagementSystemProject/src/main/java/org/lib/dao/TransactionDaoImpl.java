package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public class TransactionDaoImpl implements ITransactionDao{


	 // Establishing jdbc connection
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/lms", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {

			e.printStackTrace();
		}

		return null;

	}
	
	
	
    //Book issuing to the student
	@Override
	public boolean doTransaction(BooksTransaction bookstransaction, BooksRegistration regid) {

		String sql = "insert into BooksTransaction values(?,?,?,?,?)";

		try(Connection connection=getDbConnection())
		{
			PreparedStatement st=connection.prepareStatement(sql);
			st.setString(1, bookstransaction.getTransactionId());
			st.setString(2, regid.getRegistrationId());
			st.setDate(3, java.sql.Date.valueOf(bookstransaction.getIssueDate()));
			st.setDate(4, java.sql.Date.valueOf(bookstransaction.getReturnDate()));
			st.setInt(5, bookstransaction.getFine());

			int row=st.executeUpdate();

			if(row>0) {
				System.out.println("The Book has been issued to the student");
				return true;}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;

	}
    
	
	//Fine Calculation
	@Override
	public void calculateFine(BooksTransaction bookstransaction, String transId) {

		String sql = " UPDATE BooksTransaction SET return_date = ?, fine= ? WHERE transaction_id = ?;";

		try(Connection connection=getDbConnection())
		{
			PreparedStatement st=connection.prepareStatement(sql);
			st.setDate(1, java.sql.Date.valueOf(bookstransaction.getReturnDate()));
			st.setInt(2, bookstransaction.getFine());
			st.setString(3, transId);


			int row=st.executeUpdate();

			if(row>0)
				System.out.println("The Book has been returned and fine is calculated");

		} catch (SQLException e) {
			e.printStackTrace();
		}



	}

	@Override
	public int findFine(String userId) {

		String sql = "select * from BooksTransaction where transaction_id ="+userId+";";

		try(Connection connection=getDbConnection())
		{

			PreparedStatement st=connection.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while(rs.next()) {
				int fine = rs.getInt(5);
				return fine;
			}


		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
     
	
	// Retrieving All transaction
	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration register) {

		List<BooksTransaction> transaction =new ArrayList<>();
		String str="select * from BooksTransaction where registration_id="+register.getRegistrationId()+";";
		String str1 ="select * from BooksRegistration";
		try(Connection connection=getDbConnection())
		{
			BooksRegistration reg = new BooksRegistration();
			PreparedStatement statement=connection.prepareStatement(str);
			PreparedStatement statement1=connection.prepareStatement(str1);

			ResultSet rs= statement.executeQuery();
			ResultSet rs1= statement1.executeQuery();


			while(rs1.next())
			{

				reg.setRegistrationId(rs1.getString(1));

			}


			while(rs.next())
			{
				BooksTransaction trans =new BooksTransaction();
				trans.setTransactionId(rs.getString(1));
				trans.setRegistrationId(register);
				trans.setIssueDate(rs.getDate(3).toLocalDate());
				trans.setReturnDate(rs.getDate(4).toLocalDate());
				trans.setFine(rs.getInt(5));
				transaction.add(trans);	

			}
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return transaction;
	}

	
	//Generating the transactionId
	@Override
	public String generateTransactionId() {
		String sql = "select * from bookstransaction";
		try(Connection connection=getDbConnection()){
			PreparedStatement statement=connection.prepareStatement(sql);

			ResultSet rs= statement.executeQuery();

			String tranId=new String("199");
			while(rs.next()){
				tranId=rs.getString(1);
			}
			return String.valueOf((Long.parseLong(tranId)+1));
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	//Listing the transactions
	@Override
	public List<BooksTransaction> getAllTransaction(Users student) {
		List<BooksTransaction> transaction =new ArrayList<>();
		IRegistrationDao registrationDao=new RegistrationDaoImpl();
		String str="select * from BooksTransaction bt, booksregistration br where bt.registration_id = "
				+ "br.registration_id and br.user_id = ?;";
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);

			statement.setString(1, student.getUserId());
			ResultSet rs= statement.executeQuery();


			while(rs.next())
			{
				BooksTransaction trans =new BooksTransaction();
				trans.setTransactionId(rs.getString(1));
				trans.setRegistrationId(registrationDao.getRegistration(rs.getString(2)));
				trans.setIssueDate(rs.getDate(3).toLocalDate());
				trans.setReturnDate(rs.getDate(4).toLocalDate());
				trans.setFine(rs.getInt(5));
				transaction.add(trans);	

			}
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return transaction;
	}

}
