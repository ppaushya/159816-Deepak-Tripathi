package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.Users;

public class LoginDaoImpl implements ILoginDao{

 //Establishing jdbc Connection 
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/lms", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}

		return null;

	}

   
	//Getting All user details
	@Override
	public List<Users> getAllUsers() {

		List<Users> usersList = new ArrayList<>();
		String str="select * from Users;";

		try(Connection connection=getDbConnection()){
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet rs= statement.executeQuery();


			while(rs.next()){
				Users user = new Users();
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setPassword(rs.getString(3));;
				user.setEmailId(rs.getString(4));;
				user.setLibrarian(rs.getBoolean(5));;
				usersList.add(user);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		}
		return usersList;


	}
	
	
    // Student validation
	public boolean isValidStudent(String userName, String password, int c) {

		String sql="select * from users";
		try(Connection conn = getDbConnection()){
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rs =pst.executeQuery();
			while(rs.next()) {
				if(rs.getString(2).compareTo(userName)==0 && rs.getString(3).compareTo(password)==0 && rs.getInt(5)==c){
					return true;
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;


	}
	
	//Librarian Validation
	public boolean isValidLibrarian(String userName, String password, int c) {
		String sql="select * from users";
		try(Connection conn = getDbConnection()){

			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rs =pst.executeQuery();
			while(rs.next()) {
				if(rs.getString(2).equals(userName) && rs.getString(3).equals(password)&& rs.getInt(5)==c){
					return true;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;


	}

     
	@Override
	public List<Users> getAllUsers(int i) {
		List<Users> usersList = new ArrayList<>();
		String str="select * from Users where librarian=?;";

		try(Connection connection=getDbConnection()){
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, i);
			ResultSet rs= statement.executeQuery();


			while(rs.next()){
				Users user = new Users();
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setPassword(rs.getString(3));;
				user.setEmailId(rs.getString(4));;
				user.setLibrarian(rs.getBoolean(5));;
				usersList.add(user);
			}


		} catch (SQLException e) {
			e.printStackTrace();
		}
		return usersList;
	}

     
	@Override
	public Users getBook(String userId) {
		Users user = new Users();
		String str="select * from Users where user_id=?;";

		try(Connection connection=getDbConnection()){
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setString(1, userId);
			ResultSet rs= statement.executeQuery();


			if(rs.next()){
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setEmailId(rs.getString(3));
				user.setPassword(rs.getString(4));
				user.setLibrarian(rs.getBoolean(5));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;


	}

}
