package org.lib.dao;

import java.util.List;

import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public interface ITransactionDao {
	
	public boolean doTransaction(BooksTransaction bookstransaction, BooksRegistration regid);
	public List<BooksTransaction> getAllTransaction(BooksRegistration register);
	public void calculateFine(BooksTransaction bookstransaction, String transId);
	public String generateTransactionId();
	public List<BooksTransaction> getAllTransaction(Users student);
	int findFine(String userId);

}
