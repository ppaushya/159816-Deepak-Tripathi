package org.lib.dao;

import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;


public interface IRegistrationDao {
	
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books);
	public boolean doRegistration(BooksInventory books, Users user, BooksRegistration register);
	public void deleteRequest(String resitrationId);
	public String generateRegistrationId();
	public List<BooksRegistration> getRegistration(Users user);
	public BooksRegistration getRegistration(String string);
	public void deleteRequest(BooksTransaction bookTransaction);
}
