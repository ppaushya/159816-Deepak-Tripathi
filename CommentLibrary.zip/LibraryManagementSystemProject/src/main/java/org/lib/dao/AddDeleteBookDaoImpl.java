package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksInventory;


public class AddDeleteBookDaoImpl implements IAddDeleteBookDao {
	
	//Adding Books to library
	@Override
	public void addBook(BooksInventory booksInventory) {    
		
		String sql = "insert into BooksInventory values(?,?,?,?,?,?)";
				
		try(Connection connection=getConnection()){
			PreparedStatement st=connection.prepareStatement(sql);
			st.setString(1, booksInventory.getBookId());
			st.setString(2, booksInventory.getBookName());
			st.setString(3, booksInventory.getAuthor1());
			st.setString(4, booksInventory.getAuthor2());
			st.setString(5, booksInventory.getPublisher());
			st.setString(6, booksInventory.getYearOfPublication());
			
			
			int row=st.executeUpdate();

			if(row>0)
				System.out.println("Book has been added to the library!");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
	}

	//fetching all book details
	@Override	
	public List<BooksInventory> getAllBooks() {
		
		List<BooksInventory> bookList = new ArrayList<>();
		String str="select * from BooksInventory;";
		
		try(Connection connection=getConnection()){
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet rs= statement.executeQuery();
			
			while(rs.next()){
				BooksInventory addBook = new BooksInventory();
				addBook.setBookId(rs.getString(1));
				addBook.setBookName(rs.getString(2));
				addBook.setAuthor1(rs.getString(3));
				addBook.setAuthor2(rs.getString(4));
				addBook.setPublisher(rs.getString(5));
				addBook.setYearOfPublication(rs.getString(6));
				bookList.add(addBook);
			}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		return bookList;
}
	
	//deleting books from library
	public void deleteBook(String bookId) {
		
		String sql1 = "SET foreign_key_checks = 0";
		String sql="delete from booksinventory where book_id = ?";
		String sql2 = "SET foreign_key_checks = 1";
		try(Connection conn = getConnection()){
			
			
			PreparedStatement pst1=conn.prepareStatement(sql1);
			pst1.executeQuery();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, bookId);
			int row = pst.executeUpdate();
			
					if(row<0){
						System.out.println("Book has not been deleted");
					}
					else{
						System.out.println("Book has  been deleted");
					}
			 
			 
			 PreparedStatement pst2=conn.prepareStatement(sql2);
				pst2.executeQuery();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	
	//Book Id generation
	@Override
	public String generateBookId() {
		String sql = "select * from booksInventory";
		try(Connection connection=getConnection()){
			PreparedStatement statement=connection.prepareStatement(sql);

			ResultSet rs= statement.executeQuery();

			String bookId=new String("199");
			while(rs.next()){
				bookId=rs.getString(1);
			}
			return String.valueOf((Long.parseLong(bookId)+1));
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	//fetching book details using book_id
	@Override
	public BooksInventory getBook(String bookId) {
		BooksInventory book = new BooksInventory();
		String str="select * from BooksInventory where book_id=?;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setString(1, bookId);
			ResultSet rs= statement.executeQuery();
			
			
			if(rs.next())
			{
				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setAuthor1(rs.getString(3));
				book.setAuthor2(rs.getString(4));
				book.setPublisher(rs.getString(5));
				book.setYearOfPublication(rs.getString(6));
			}
		
	} catch (SQLException e) {
		e.printStackTrace();
	}
		return book;
	}
	
	//Establishing jdbc connection
	private Connection getConnection(){
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/lms", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	
	
}
