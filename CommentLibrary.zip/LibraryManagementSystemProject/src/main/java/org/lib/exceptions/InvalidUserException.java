package org.lib.exceptions;

public class InvalidUserException extends Exception {
        
	public InvalidUserException (String str)
	{
		super(str);
	}
}
