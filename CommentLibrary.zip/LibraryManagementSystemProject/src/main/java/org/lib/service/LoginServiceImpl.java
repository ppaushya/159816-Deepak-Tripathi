package org.lib.service;


import org.lib.bean.Users;
import org.lib.dao.ILoginDao;
import org.lib.dao.LoginDaoImpl;
import org.lib.exceptions.InvalidUserException;

import java.util.List;

import org.apache.log4j.Logger;
import org.lib.util.Utility;

public class LoginServiceImpl implements ILoginService{

	public final static Logger logger=Logger.getLogger(LoginServiceImpl.class);

	ILoginDao loginDao = new LoginDaoImpl();

	public LoginServiceImpl(ILoginDao loginDao) {
		super();
		this.loginDao = loginDao;
	}


	public LoginServiceImpl() {
		
	}

	@Override
	public boolean isValidStudent(String userName, String password, int c) {

		if(Utility.isvaliduser(userName)){
			return loginDao.isValidStudent(userName, password, c);
		}else{
			logger.error("customer is invalid");	
			try {
				throw new InvalidUserException("details not in proper format..so account cant be created");
			} catch (InvalidUserException e) {
				e.printStackTrace();
			}

		}
		return false;
	}
	@Override
	public boolean isValidLibrarian(String userNameLib, String passwordLib, int c) {

		if(Utility.isvaliduser(userNameLib))
		{
			boolean turn = loginDao.isValidLibrarian(userNameLib, passwordLib, c);
			return turn;
		}else
		{
			logger.error("User is invalid");	
			try {
				throw new InvalidUserException("Details not in proper format..so  cant login");
			} catch (InvalidUserException e) {
				e.printStackTrace();
			}

		}
		return false;
	}



	@Override
	public List<Users> getAllUsers() {
		return loginDao.getAllUsers();
	}



	@Override
	public List<Users> getAllUsers(int i) {
		return loginDao.getAllUsers(i);
	}


}
