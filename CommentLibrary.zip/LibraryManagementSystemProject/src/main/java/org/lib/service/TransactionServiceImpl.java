package org.lib.service;

import java.util.List;

import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.dao.ITransactionDao;
import org.lib.dao.TransactionDaoImpl;

public class TransactionServiceImpl implements ITransactionService {

	ITransactionDao transactionDao = new TransactionDaoImpl(); 
	
	
	
	
	public TransactionServiceImpl(ITransactionDao transactionDao) {
		super();
		this.transactionDao = transactionDao;
	}

	public TransactionServiceImpl() {

	}

	@Override
	public boolean doTransaction(BooksTransaction booksTransaction, BooksRegistration regid) {
	
		return transactionDao.doTransaction(booksTransaction,regid);
		
	}

	@Override
	public int findFine(String userid) {
		
		return transactionDao.findFine(userid);
		
	}

	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration register) {
		return transactionDao.getAllTransaction(register);
	}

	@Override
	public void calculateFine(BooksTransaction booksTransaction, String transId) {
		transactionDao.calculateFine(booksTransaction,transId);
	}

	@Override
	public String generateTransactionId() {
		return transactionDao.generateTransactionId();
	}

	@Override
	public List<BooksTransaction> getAllTransaction(Users student) {
		return transactionDao.getAllTransaction(student);
	}

	

	

}
