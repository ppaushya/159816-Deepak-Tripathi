package org.lib.test;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.Users;
import org.lib.dao.RegistrationDaoImpl;
import org.lib.service.RegistrationServiceImpl;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class RequestTest {

	@Mock
    private RegistrationDaoImpl registerDao;
	
	private RegistrationServiceImpl registerService;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		registerService= new RegistrationServiceImpl(registerDao);
	}
	

	
	@Test
	
	public void test_acc_with_alllogin_format()
	{
	  
		BooksInventory books = new BooksInventory();
		Users user = new Users();
		BooksRegistration register = new BooksRegistration();
    	
		
	   register.setRegistrationId("101");
	   register.setBookId(books);
	   register.setUserId(user);
	   register.setRegistrationdate(LocalDate.now());
	   
	   Mockito.when(registerDao.doRegistration(books, user, register)).thenReturn(true);
	   
	   registerService.doRegistration(books, user, register);
	   
	   
	   Mockito.verify(registerDao).doRegistration(books, user, register);
	   
	   
	   
	}
	
}
