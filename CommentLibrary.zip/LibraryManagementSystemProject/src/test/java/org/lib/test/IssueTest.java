package org.lib.test;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.dao.TransactionDaoImpl;
import org.lib.service.TransactionServiceImpl;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class IssueTest {

	@Mock
    private TransactionDaoImpl transactionDao;
	
	private TransactionServiceImpl transactionService;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		transactionService= new TransactionServiceImpl(transactionDao);
	}
	

	
	@Test
	
	public void test_acc_with_alllogin_format()
	{
	  
	   
		BooksRegistration register = new BooksRegistration();
    	BooksTransaction bookstransaction = new BooksTransaction();
		
    	bookstransaction.setTransactionId("101");
    	bookstransaction.setRegistrationId(register);
    	bookstransaction.setIssueDate(LocalDate.now());
    	bookstransaction.setReturnDate(LocalDate.of(2018, 02, 22));
    	bookstransaction.setFine(0);
    	
    	
	   
	   Mockito.when(transactionDao.doTransaction(bookstransaction,register)).thenReturn(true);
	   
	   transactionService.doTransaction(bookstransaction,register);
	   
	   Mockito.verify(transactionDao).doTransaction(bookstransaction,register);
	   
	   
	   
	}
	
}
