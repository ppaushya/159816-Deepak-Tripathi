package org.up.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
java.sql.Date;

import org.up.model.Account;
import org.up.model.Address;
import org.up.model.Customer;
import org.up.services.CustomerServiceImpl;

public class CustomerDaoImpl implements ICustomerDao{

	@Override
	public void createCustomer(Customer customer) {
		
		CustomerServiceImpl obj=new CustomerServiceImpl(null);
		String SQL = "insert into customer(customerId,firstName,lastName,dateOfBirth,emailId,mobile) values(?,?,?,?,?,?)";
		String nextSQL="select * from customer";
		try(Connection con = getDbConnection())
		{
		     java.sql.PreparedStatement prepared=con.prepareStatement(SQL);
		     prepared.setInt(1, customer.getCustomerId());
		     prepared.setString(2, customer.getFirstName());
		     prepared.setString(3,customer.getLastName());
		     prepared.setDate(4, customer.getDateOfBirth());
		     prepared.setString(5, customer.getEmailId());
		     prepared.setString(5, customer.getMobile());
		    
		     int count=prepared.executeUpdate();		    
		     

		     if(count>=1)
		     {
		    	 System.out.println("Insertion done!"); 
			     
		     }
		     else
		     {
		    	 System.out.println("insertion error");
		     }
		     
		     
		} 
		/*catch (SQLException e) {
			// TODO Auto-generated catch block
			obj.logger.error("connection error",e);
			//e.printStackTrace();
		}*/
		
	}
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}
	
@Override
	
	public void createaccounts(Customer customer,Account account) {
	String SQL = "insert into account(AccountNumber,AccountType,OpeningDate,OpeningBalance,Description) values(?,?,?,?,?)";
	String nextSQL="select * from customer";
	try(Connection connection = getDbConnection())
	{
		java.sql.PreparedStatement preparedStatement=connection.prepareStatement(nextSQL);
	     
	     ResultSet res=preparedStatement.executeQuery();
	     
	     while(res.next())
	     {
	    	 if(res.getString(2).compareTo(customer.getFirstName())==0)
	    	 { 
	    		 
	    		java.sql.PreparedStatement prepared=connection.prepareStatement(SQL);
			     prepared.setLong(1, account.getAccountNumber());
			     prepared.setString(2, account.getAccountType());
			     prepared.setDate(3,account.getOpeningDate());
			     prepared.setDouble(4, account.getOpeningBalance());
			     prepared.setString(5, account. getDescription());
			    
			     int count=prepared.executeUpdate();		    
			     
	
				     if(count>=1)
				     {
				    	 System.out.println("Insertion done!"); 
					     
				     }
				     else
				     {
				    	 System.out.println("insertion error");
				     }
		    	 }
	     }  
	     
	    
		
		}
	}

	
	public  List<Customer> getAllCustomer(){
		List<Customer> list=new ArrayList<Customer>();
		try{
			Connection con = getDbConnection();
			PreparedStatement ps=con.prepareStatement("select * from customer");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Customer bean=new Customer();
				bean.setCustomerId(rs.getInt(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setDateOfBirth(rs.getString(4));
				bean.setEmailId(rs.getString(5));
				bean.setMobile(rs.getString(6));
				list.add(bean);
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		
		return list;
	}
	
	public Set<Account> getAllAccounts(int id){
		Set<Account> list1=new HashSet<Account>();
		try{
			Connection con = getDbConnection();
			PreparedStatement ps=con.prepareStatement("select * from account join customer on customer.customerId = account.customerId where customerId=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Account acc =new Account();
				acc.setAccountNumber(rs.getLong(1));
				acc.setAccountType(rs.getString(2));
				acc.setOpeningDate(rs.getDate(3));
				acc.setOpeningBalance(rs.getDouble(4));
				acc.setDescription(rs.getString(5));
				//acc.add(list1);
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		
		return list1;
	}
}


	
