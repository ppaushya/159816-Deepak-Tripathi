package org.up.dao;

import java.util.List;
import java.util.Set;

import org.up.model.Account;
import org.up.model.Customer;

public interface ICustomerDao {
	
	public  List<Customer> getAllCustomer();
	public Set<Account> getAllAccounts(int id);
	public void createCustomer(Customer customer);
    public void createaccounts(Customer customer,Account account);
}

