package org.cap;


enum CustomerType
{
	SILVER(0,100), GOLD(101,200), DIAMOND(201,300), PLATINUM(301,500);
	private int minrewardPoints;
	private int maxrewardPoints;
	
	
	private CustomerType(int minrewardPoints, int maxrewardPoints)
	{
		this.minrewardPoints=minrewardPoints;
		this.maxrewardPoints=maxrewardPoints;
	}
	
	public int getminrewardPoints()
	{
		return this.minrewardPoints;
	}
	
	public int getmaxrewardPoints()
	{
		return this.maxrewardPoints;
	}
}
public class Customer {

	int customerId ;
	String customerName;
	CustomerType customerType;
	
	public void getEmployee()
	{
		customerId =100;
		customerName = "Tom";
		customerType = CustomerType.SILVER;
		
	}
	
	public void printEmployee()
	{
		System.out.println(customerId + ", " + customerName + " ," + customerType + " \nRange for Silver is:" + customerType.getminrewardPoints()+ "-"+customerType.getmaxrewardPoints());

	}
	
	public static void main(String[] args) {
		
		Customer cus = new Customer();
		cus.getEmployee();
		cus.printEmployee();
	}

}
