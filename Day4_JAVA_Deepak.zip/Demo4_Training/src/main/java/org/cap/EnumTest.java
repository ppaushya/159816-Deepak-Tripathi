package org.cap;

public enum EnumTest {
	
	SUNDAY(1), MONDAY(2), TUESDAY(3), WEDNESDAY(4);
	
	int value;
	
	//Enum constructor//
	private EnumTest(int var)
	{
		this.value=var;
	}
	
	public int getValue()
	{
		return this.value;
	}

}
