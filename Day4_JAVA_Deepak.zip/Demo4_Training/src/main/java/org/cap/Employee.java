package org.cap;


public class Employee {

	int EmpId;
	String firstName;
	String lastName;
	int age;
	double salary;
	EnumTest weekoff;
	
	public void getEmployee()
	{
		EmpId =100;
		firstName = "Tom";
		lastName = "Jerry";
		age = 12;
		salary = 20000;
		weekoff = EnumTest.MONDAY;
		
	}
	
	public void printEmployee()
	{
		System.out.println(EmpId + "  " + firstName + " " + lastName + " " + age + " "+ " " + salary + " "+  weekoff+" " +weekoff.getValue());
		
	}
	public static void main(String[] args)
	{
		Employee emp = new Employee();
		emp.getEmployee();
		emp.printEmployee();
		
		
	}
	
}
