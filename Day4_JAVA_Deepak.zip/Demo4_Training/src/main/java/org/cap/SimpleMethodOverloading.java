package org.cap;

public class SimpleMethodOverloading {

	int principal;
	int rate;
	int year;
	int interest;
	

	
	public  SimpleMethodOverloading(int princ, int rat, int yr)
	{
		this.principal = princ;
		this.rate = rat;
		this.year = yr;
	}
	
	public int SimpleInterest()
	{
		
		interest =principal*rate*year/100;
		return interest;
	}
	
	public int SimpleInterest(int princ)
	{
		
		interest =princ*rate*year/100;
		return interest;
	}
	
	public int SimpleInterest(int princ, int rat)
	{
		
		interest =princ*rat*year/100;
		return interest;
	}
	public static void main(String[] args) {
	

	SimpleMethodOverloading prod4 = new  SimpleMethodOverloading(100,5,2);
						System.out.println(prod4.SimpleInterest());
						System.out.println(prod4.SimpleInterest(200));
						System.out.println(prod4.SimpleInterest(300, 5));
	
		
	}
}
