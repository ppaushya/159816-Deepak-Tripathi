package org.cap;

public class StringDemo {

	
	public static void main(String[] args) 
	{
		String str = "Tom";
		String myStr = new String("Jerry");
		String myname = "Tom";
		System.out.println(str.hashCode());
		System.out.println(myStr.hashCode());
		System.out.println(myname.hashCode());
	}
}
