package org.cap;

public class ProductClass {
	
	int productId;
	String productName;
	double price;
	int qty;
	
	ProductClass()
	{//Executable Statements: It will execute but not the appropriate place to put the constructor//
		System.out.println("Default Constructor");
	}
	
	/*protected ProductClass()
	{
		System.out.println("Default Constructor");
	}*/
	
	/*public ProductClass()
	{
		System.out.println("Default Constructor");
	}*/
	
	public ProductClass(int prodId)
	{
		System.out.println("Overloaded Constructor");
		this.productId =prodId;
	}
	
	@Override
	public String toString() {
		return "ProductClass [productId=" + productId + ", productName=" + productName + ", price=" + price + ", qty="
				+ qty + "]";
	}

	public ProductClass(int prodId, String productName, double price, int qty )
	{
		System.out.println("Overloaded Constructor with all args");
		System.out.println("  " + productId + ", " + productName + ", " + price + ", " + qty);
	}
	
	
	public void printProduct()
	{
		System.out.println("  " + productId + ", " + productName);
	
	}
	
	
	public static void main(String[] args)
	{
		ProductClass prod = new ProductClass();
		System.out.println(prod);
		
		ProductClass prod2 = new ProductClass(1001);
		System.out.println(prod2);
		
		ProductClass prod4 = new ProductClass(1001);
		System.out.println(prod4);
		
		ProductClass prod5 = new ProductClass(1001);
		System.out.println(prod5);
		
		prod2.printProduct();
		
		ProductClass prod3 = new ProductClass(1001, "lalit", 20, 200);
		System.out.println(prod3);
		ProductClass prod9 = new ProductClass(1002, "lat", 220, 2002);
		System.out.println(prod3.hashCode());
		System.out.println(prod9.hashCode());
		
	}

}
