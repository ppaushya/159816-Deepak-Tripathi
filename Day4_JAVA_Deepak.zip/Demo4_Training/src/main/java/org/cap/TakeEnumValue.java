package org.cap;

import java.util.Scanner;



public class TakeEnumValue {
	Scanner scanner = new Scanner(System.in);
	int employeeId;
	String fname;
	String lname;
	int age;
	float salary;
	int temp;
	EnumTest weekoff;
	
	public void getData()
	{
				System.out.println("Enter Employee ID");
			    employeeId = scanner.nextInt();
				System.out.println("Enter First Name:");
			    fname = scanner.next();
				System.out.println("Enter Last Name:");
				lname = scanner.next();
				System.out.println("Age");
				age = scanner.nextInt();
				System.out.println("Salary");
				salary = scanner.nextFloat();
				System.out.println("Enter WeekDay");
				temp = scanner.nextInt();
	}
		
	
	
	public void printEmployee()
	{
		if(temp==1)
		{
			weekoff = EnumTest.SUNDAY;
			System.out.println(employeeId + " \n " + fname + " \n" + lname + " \n" + age + " \n"+  salary + " \n"+  weekoff+" \n" +weekoff.getValue());
			
		}
		else if(temp==2)
		{
			weekoff = EnumTest.MONDAY;
			System.out.println(employeeId + " \n " + fname + " \n" + lname + " \n" + age + " \n"+  salary + " \n"+  weekoff+" \n" +weekoff.getValue());
		}
		else if(temp==3)
		{
			weekoff = EnumTest.TUESDAY;
			System.out.println(employeeId + " \n " + fname + " \n" + lname + " \n" + age + " \n"+  salary + " \n"+  weekoff+" \n" +weekoff.getValue());
			
		}
		else if(temp==4)
		{
			weekoff = EnumTest.WEDNESDAY;
			System.out.println(employeeId + " \n " + fname + " \n" + lname + " \n" + age + " \n"+  salary + " \n"+  weekoff+" \n" +weekoff.getValue());
			
		}
		else
		{
			System.out.println("NOT A VALID OPTION");
		}
			
	}
	public static void main(String[] args)
	{

		TakeEnumValue emp = new TakeEnumValue();
		emp.getData();
		emp.printEmployee();
		
		
	}
}
