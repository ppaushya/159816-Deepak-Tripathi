package org.cap; 

import java.util.Arrays;

public class TestClasa {

	public static void main(String[] args) {
		int[] arr = {10,20,40,50,12};
		int[] myArr= Arrays.copyOfRange(arr,2,arr.length);
		Arrays.sort(arr);
		
		for(int i=0; i<arr.length; i++)
		{
			System.out.println(arr[i]);
		}
		
		String[] arr2 = {"Deepak","Sumit","Tom","Abhishek","Pushkar"};
		Arrays.sort(arr2);
		
		for(int i=0; i<arr2.length; i++)
		{
			System.out.println(arr2[i]);
		}
		
		for(int i=0; i<myArr.length; i++)
		{
			System.out.println(myArr[i]);
		}
		
		
	}
	
	
}
