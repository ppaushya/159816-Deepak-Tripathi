package org.cap;

public class MethodExamples {

	   public static void main(String[] args) {

		      String str = "DeepakTripathi";
		      String str1 = "AbhishekTripathi";
		      System.out.println("String = " + str);
		      System.out.println("String = " + str1);
		      System.out.println(str.charAt(5));
		      int retval = str.codePointAt(1);
		      System.out.println("Character(unicode point) = " + retval);
		      System.out.println(str.compareTo(str1)==1);
		      System.out.println(str.compareToIgnoreCase(str1)==1);
		      System.out.println(str.concat(str1));
		      CharSequence cs1 = "Tripathi";
		      boolean retval1 = str.contains(cs1);
		      System.out.println("Method returns : " + retval1);
		      boolean retval2 = str1.contentEquals(cs1);
		      System.out.println("Method returns : " + retval2);
		      String strcpy = String.copyValueOf(str.toCharArray());
		      System.out.println("Stringcpy = " + strcpy);
		      String strcpy1 = String.copyValueOf(str.toCharArray(), 0 , str.length());
		      System.out.println("Stringcpy = " + strcpy1);
		      System.out.println(str.endsWith("c"));
		      System.out.println(str.equals(str1));
		      System.out.println(str.equalsIgnoreCase(str1));
		      System.out.println(str.compareTo(str1)==1);
		      System.out.println(str.getBytes());
		      
		     
		   } 
}
