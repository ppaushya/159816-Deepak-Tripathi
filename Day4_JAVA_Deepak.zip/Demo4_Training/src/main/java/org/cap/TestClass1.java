package org.cap;

public class TestClass1 {

	
	public static void main(String[] args)
	{
		EnumTest[] values = EnumTest.values();
		
		for (EnumTest day: values)
		{
			System.out.println(day);
			
		}
		
		String str = "SUNDAY";
		EnumTest yourday = EnumTest.valueOf(EnumTest.class, str);
		System.out.println(yourday);
				
	}
}
