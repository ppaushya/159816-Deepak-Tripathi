package org.cap.demo;

import java.util.Scanner;

public class MinimumArray {

	
	int row;
	int col;
	
	public static void main(String[] args)
	{
		int[][] arr1=new int[3][3];
		int[] arr2=new int[3];
		int d = 0;
		MinimumArray two = new MinimumArray();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Rows");
		two.row = scanner.nextInt();
		System.out.println("Enter Columns");
		two.col = scanner.nextInt();
		
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr1[i][j]=scanner.nextInt();
				}
				System.out.println();
			}
		    
			for(int i=0; i<two.row; i++)
			{
				for(int j=0; j<two.col; j++)
				{
					arr2[i]=arr1[i][j]+arr2[i];
					d =arr2[i]+d;
				}
				System.out.println();
			}
			
			int min=arr2[0];
			for(int i=0;i<arr2.length;i++)
			{
				if(min>arr2[i])
					min=arr2[i];
			}
			System.out.println(min);
		  
		
	}
}