package org.lib.dao;

import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public interface ITransactionDao {
	
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid);
	public int findfine(String userid);
	public List<BooksTransaction> getAllTransaction(BooksRegistration regid);
	public void calculateFine(BooksTransaction bookstransaction);

}
