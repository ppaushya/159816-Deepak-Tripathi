package org.lib.boot;

import java.util.List;
import java.util.Scanner;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.service.AddDeleteBookServiceImpl;
import org.lib.service.IAddDeleteBookService;
import org.lib.service.ILoginService;
import org.lib.service.IRegistrationService;
import org.lib.service.ITransactionService;
import org.lib.service.LoginServiceImpl;
import org.lib.service.RegistrationServiceImpl;
import org.lib.service.TransactionServiceImpl;
import org.lib.view.UserInteraction;

public class BootClass {
	
	
	
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		Users users = new Users();
		ILoginService loginService = new LoginServiceImpl();
		IAddDeleteBookService adddeleteservice = new AddDeleteBookServiceImpl();
		IRegistrationService regService = new RegistrationServiceImpl();
		ITransactionService tranService = new TransactionServiceImpl();
		UserInteraction userinteraction = new UserInteraction();
		boolean stop = true;;
		 
		do {   
			 
	            // FRONT END //
	            System.out.println("--------------------------------------------------------");
	            System.out.println("\tWelcome to Library");
	            System.out.println("--------------------------------------------------------");
	            
	            System.out.println("Following Functionalities are available: \n");
	            System.out.println("1- Login as a student");
	            System.out.println("2- Login as a librarian");
	            System.out.println("3- Exit");
	            
	            System.out.println("-----------------------------------------\n");        
	            
	            System.out.println("Enter Your Choice");
	            int choice = 0;
	            choice = scanner.nextInt();
	           
	            switch(choice)
	            { 
	            case 1:
				            	 System.out.println("\nEnter User Name: ");  
					            	String userName = scanner.next();
					                System.out.println("\nEnter Password: ");
					                String password = scanner.next();
			
				                if (userName == null || password ==null){
				                	
				                	System.out.println("Sorry! You have missed information required");
				                	System.exit(0);
				                }
				                
				                else if (loginService.validStudent(userName, password, 0))
				                {                    
				                   do   
				                    {
				                        
				                                        
				                        System.out.println("--------------------------------------------------------");
				                        System.out.println("\t  Welcome to Student's Portal");
				                        System.out.println("--------------------------------------------------------");
				                        System.out.println("These functionalities are available for Student: \n");
				                        System.out.println("1- List all books");
				                        System.out.println("2- Request a book to be issued");
				                        System.out.println("3- Check total fine");                       
				                        System.out.println("4- Logout");
				                        System.out.println("-------------------------------------------------------");
				                        
				                       
				                       
				                        System.out.println("Enter your Choice");
				                        int ch = scanner.nextInt();
				                        switch(ch)
				                        {
				                        case 1:
					                        	List<BooksInventory> books = adddeleteservice.getallbooks();
					                        	userinteraction.printBooks(books);
					                        	break;
				                        case 2:
					                        	List<BooksInventory> bookIns = adddeleteservice.getallbooks();
					                        	userinteraction.printBooks(bookIns);
					                        	List<Users> users1 = loginService.getallusers();
					                        	BooksInventory bookInventory = userinteraction.findallbooks(bookIns);
					                        	BooksInventory book = new BooksInventory();
					                        	Users user = new Users();
					                        	
					                        	if(bookInventory==null)
					                        	{
					                        		System.out.println("Not a Valid Book");
					                        	}
					                        	else
					                        	{

					                        		System.out.println("Enter Book_Id");
					                        		String book_id = scanner.next();
					                        		book = userinteraction.getBook(book_id, bookIns);
					                        		
					                        		System.out.println("Enter User_Id");
					                        		String user_id = scanner.next();
					                        		user = userinteraction.getUser(user_id, users1);
					                        		regService.doRegistration(book, user, userinteraction.register(book, user));
					                        	}
					                        	
				                        	   	break;
				                        case 3:			
				                        	
					                        	System.out.println("Enter Transaction_id");
			                        			String trans_id = scanner.next();
					                        	System.out.println(tranService.findfine(trans_id));
					                        	break;
				                        case 4:
				                        		stop = false;
				                        		System.out.println("You have been logged out!!!");
				                        	   break;
				                        }
				                        
				                    }while(stop);
				                } else {
				                	System.out.println("No you are unauthorised to access");
				                	break;
				                }
				                System.exit(0);
				                
				                  
	            case 2:
				            	 System.out.println("\nEnter User Name: ");  
					            	String userNameLib = scanner.next();
					                System.out.println("\nEnter Password: ");
					                String passwordLib = scanner.next();
			
				                if (userNameLib == null){
				                	
				                	System.out.println("Sorry! You have missed information required");
				                	System.exit(0);
				                }
				                else if (loginService.validLibrarian(userNameLib, passwordLib, 1))
				                {
				                    do 
				                    {
				                                        
				                        System.out.println("------------------------------------------------------------------");
				                        System.out.println("\t   Welcome to the Librarian's Portal");
				                        System.out.println("------------------------------------------------------------------");
				                        System.out.println("These functionalities are available for the librarian: \n");   
				                        System.out.println("1- List all book");
				                        System.out.println("2- Do you want to add new book?");
				                        System.out.println("3- Do you want to remove book?");  
				                        System.out.println("4- Check and confirm requests of a book");
				                        System.out.println("5- Input return date and do final transaction");                   
				                        System.out.println("6- Logout");
				                        System.out.println("--------------------------------------------------------");
				                        
				                        System.out.println("Enter your Choice");
				                        int ch = scanner.nextInt();
				                        switch(ch)
				                        {
				                        case 1:
					                        	List<BooksInventory> books = adddeleteservice.getallbooks();
					                        	userinteraction.printBooks(books);
					                        	break;
				                        case 2:
				                        	
			                        		adddeleteservice.addBook(userinteraction.getDetailsofBook());
			                        	    break;
				                        case 3:
				                        	List<BooksInventory> books1 = adddeleteservice.getallbooks();
				                        	userinteraction.printBooks(books1);
				                        	System.out.println("Enter the Book Id to be deleted");
				                        	String bookId =scanner.next();
				                        	adddeleteservice.deleteBook(bookId);
		                        	   break;  
		                        	   
				                        
				                        case 4:
				                        	BooksInventory book = new BooksInventory();
				                        	List<Users> users2 = loginService.getallusers();
				                        	Users user = new Users();
			                        		System.out.println("Enter User_Id");
			                        		String user_id1 = scanner.next();
			                        		user = userinteraction.getUser(user_id1, users2);
			                        		
			                        		List<BooksInventory> bookIns2 = adddeleteservice.getallbooks();
			                        		System.out.println("Enter Book_Id");
			                        		String book_id = scanner.next();
			                        		book = userinteraction.getBook(book_id, bookIns2);
			                        		
			                        		List<BooksRegistration> bookregister = regService.getRegistration(user, book);
			                        		userinteraction.printRegistrationRequest(bookregister);
			                        		System.out.println("Enter the registrationId for whom you want to issue a book");
			                        		String regId3 = scanner.next();
			                        		System.out.println("Your Registration has been done");
		                        	   break;
		                        	   
		                        	   
				                        case 5:
					                       
				                        	
				                        	BooksRegistration bookreg = new BooksRegistration();
			                        		Users user1 = new Users();
				                        	List<Users> users5 = loginService.getallusers();
				                        	Users user2 = new Users();
				                        	BooksRegistration bookreg1 = new BooksRegistration();
			                        		System.out.println("Enter User_Id");
			                        		String userId4 = scanner.next();
			                        		user1 = userinteraction.getUser(userId4, users5);
			                        		
			                        		List<BooksInventory> bookIns4 = adddeleteservice.getallbooks();
			                        		System.out.println("Enter Book_Id");
			                        		String bookid1 = scanner.next();
			                        		book = userinteraction.getBook(bookid1, bookIns4);
			                        		
			                        		List<BooksRegistration> registers2 = regService.getRegistration(user1, book);
			                        		userinteraction.printRegistrationRequest(registers2);
			                        		System.out.println("Enter the registrationId for whom you want to issue a book");
			                        		String regId2 = scanner.next();
			                        		bookreg = userinteraction.getRegister(regId2, registers2);
			                        		System.out.println("Enter Transaction_id");
		                        			String trans_id = scanner.next();
			                        		tranService.doTransaction(userinteraction.transaction(bookreg,trans_id), bookreg);
				                        	System.out.println("Your fine is : " + tranService.findfine(trans_id));
			                        		regService.deleteRequest(regId2);
				                        	
				                        break;
				                      
				                        case 6:
				                        	
				                        		System.out.println("You have been logged out!!!");
				                        		stop = false;
				                        	    break;
				                        }
				                                                                      
				                    } while(stop);                   
				                }
				                else {
				                	System.out.println("No you are unauthorised to access!!");
				                	break;
				                }
				                
	            		
			
	            case 3:
				                	stop = false; 
				                	break;
				        }
	            }
				        
				        	while(stop);
	        }
	

}

