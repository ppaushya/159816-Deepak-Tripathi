package org.cap.demo.asignment;

import org.cap.demo.override;

public class Circle implements Shape,Color{
	
	@override
	public void draw()
	{
		Points();
		System.out.println("We are Indians");
	}
	
	public void info()
	{
		Shape.show();
		System.out.println("Main hoon hero");
	}
	
	public void fillColor()
	{
		System.out.println("redbg");
	}
	
	public void fillColorLine()
	{
		System.out.println("redline");
	}

}
