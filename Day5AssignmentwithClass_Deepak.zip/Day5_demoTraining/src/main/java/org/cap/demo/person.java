package org.cap.demo;

import java.util.Scanner;

public class person {

	int personid;
	
	String firstname,lastname;
	
	public void getpersondetails()
	{
	   Scanner s = new Scanner(System.in);
	   personid=s.nextInt();
	   
	   firstname=s.nextLine();
	   
	   lastname=s.nextLine();
	   
	}
	

	public void showperson()
	{
		System.out.println(personid+" "+firstname+" "+lastname);
	}
	
	public void show()
	{
		System.out.println("Person Class --> show Method ");
	}
	
	

}
