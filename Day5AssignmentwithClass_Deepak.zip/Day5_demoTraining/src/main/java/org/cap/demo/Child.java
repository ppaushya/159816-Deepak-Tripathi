package org.cap.demo;

public class Child extends Parent{
	
	public Child()
	{
		System.out.println("Child");
	}
	public void Parent()
	{
		showParent();
	}
	
	public void calculate()
	{
		System.out.println("Calculate --> ChildClass");
	}
	
}
