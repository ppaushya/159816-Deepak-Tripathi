package org.cap.demo.asignment;

public abstract class Worker {

	
	String workerName;
	int SalaryRate = 200;
	
	
	public Worker(String workerName, int salaryRate) {
		super();
		this.workerName = workerName;
		SalaryRate = salaryRate;
	}

	
	
	public abstract double ComPay();
}
