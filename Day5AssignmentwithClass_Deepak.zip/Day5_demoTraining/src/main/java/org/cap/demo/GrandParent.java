package org.cap.demo;

public class GrandParent{

	
	public GrandParent()
	{
		System.out.println("GrandParent");
	}
	
	protected int num=1000;
}
