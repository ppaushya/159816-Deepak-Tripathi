package org.cap.demo.asignment;

public class MainClass {

}
