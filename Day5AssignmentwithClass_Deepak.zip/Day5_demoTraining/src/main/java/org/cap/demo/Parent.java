package org.cap.demo;

public class Parent extends GrandParent {
	
	
	public Parent()
	{
		System.out.println("Parent");
	}
	
	int num = 200;
	public void showParent()
	{
		System.out.println(num);
	}
	
	
	public void calculate()
	{
		System.out.println("Calculate -->ParentClass");
	}

}
