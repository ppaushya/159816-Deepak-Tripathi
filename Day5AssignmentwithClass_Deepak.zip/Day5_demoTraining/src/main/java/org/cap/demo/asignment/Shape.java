package org.cap.demo.asignment;

public interface Shape {
	
	public final static int num=199;//Keep constants in interfaces//
	public abstract void draw();
	public abstract void info();
	public abstract void fillColor();
	public abstract void fillColorLine();

	public static void show()
	{
		System.out.println("Shape interface show method");
	}
	

	default void Points()
	{
		System.out.println("Shape interface points method");
	}
	

	private static void details()
	{
		System.out.println("Shape interface details method");
	}
}
