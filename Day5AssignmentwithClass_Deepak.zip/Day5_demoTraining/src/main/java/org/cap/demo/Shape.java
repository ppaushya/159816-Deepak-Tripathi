package org.cap.demo;

public abstract class Shape {

	int width;
	int height;

	public void info()
	{
		System.out.println("Shape Information");
	}
	
	public Shape(int width, int height) {
		super();
		this.width = width;
		this.height = height;
	}

	public Shape() {
		super();
	}

	public abstract void draw();
	
	public static void main(String[] args) {
		
		
	}

}
