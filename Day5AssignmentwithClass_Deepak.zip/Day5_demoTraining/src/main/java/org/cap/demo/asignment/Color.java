package org.cap.demo.asignment;

public interface Color {

	
	public void fillColor();
	public void fillColorLine();
}
