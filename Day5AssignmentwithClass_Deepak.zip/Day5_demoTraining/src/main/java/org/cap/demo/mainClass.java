package org.cap.demo;

public class mainClass {

	
	public static void main(String args[]) 
	{
		Employee emp = new Employee();
		person person = new person();
		person per = new Employee();
		//Employee Emp4 = new person();
		/*Employee emp2 = new Employee(2000, true);
		emp.getEmployee();
		emp.showEmployee();
		emp.getpersondetails();
		emp.showperson();*/
		person.show();
		per.show();
		emp.show();
		
	}
}
