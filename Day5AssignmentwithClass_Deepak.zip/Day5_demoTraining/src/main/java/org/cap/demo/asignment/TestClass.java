package org.cap.demo.asignment;

public class TestClass {
	
	public static void main(String[] args)
	{
		Shape circle=new Circle();
		circle.draw();
		circle.info();
		circle.Points();
		circle.fillColor();
		circle.fillColorLine();
	}

}
