package org.cap.demo;

import java.util.Scanner;

public class Employee extends person{
	
	double salary;
	boolean isPermanent;
	
	public void getEmployee()
	{
		 Scanner s = new Scanner(System.in);
		   salary =s.nextDouble();
		   isPermanent=s.nextBoolean();	   
	}
	
	public Employee() {
		super();
	}

	public Employee(double salary, boolean isPermanent) {
		super();
		this.salary = salary;
		this.isPermanent = isPermanent;
	}
	
	@override
	public void show()
	{
		System.out.println("Employee Class --> show Method ");
	}

	public void showEmployee()
	{
		System.out.println(salary+" "+isPermanent);
	}

}
