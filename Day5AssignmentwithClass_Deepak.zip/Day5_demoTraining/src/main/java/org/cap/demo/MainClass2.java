package org.cap.demo;

public class MainClass2 {

	
	public static void main (String[] args) 
	{
		Child child=new Child();
		child.showParent();
		Parent parent = new Parent();
		parent.calculate();
		child.calculate();
	}
}
