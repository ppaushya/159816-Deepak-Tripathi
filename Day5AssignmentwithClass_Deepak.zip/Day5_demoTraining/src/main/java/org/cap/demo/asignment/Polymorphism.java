package org.cap.demo.asignment;

public class Polymorphism {

	String callType;
	float duration;
	
	
	
	
	public double calculate( int duration)
	{
		double price=0;
		if(callType=="ordinary")
		{
			price = 100*duration;
		}
		if(callType=="urgent")
		{
			price = 200*duration;
		}
		if(callType=="lightning")
		{
			price = 300*duration;
		}
		return price;
	}
	
	public double calculate12()
	{
		double price=0;
		if(callType=="ordinary")
		{
			price = 100*duration;
		}
		if(callType=="urgent")
		{
			price = 200*duration;
		}
		if(callType=="lightning")
		{
			price = 300*duration;
		}
		return price;
	}
	
	public Polymorphism(String callType) {
		super();
		this.callType = callType;
	}

	public Polymorphism(String callType, float duration) {
		super();
		this.callType = callType;
		this.duration = duration;
	}

	public static void main(String[] args)
	{
		Polymorphism pr=new Polymorphism("ordinary");
		Polymorphism pr1=new Polymorphism("lightning",25);
		System.out.println(pr.calculate(20));
		System.out.println(pr1.calculate12());
	}
	
}
