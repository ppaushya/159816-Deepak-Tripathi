package Balance;
  

import java.util.*;

public class Account {

	float balance;
	
	public void displayBalance()
	{
		Scanner s = new Scanner(System.in);
	   
		System.out.println("enter the balance");
		
		balance=s.nextFloat();
		
	   System.out.println("balance is "+balance);	
	   
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

} 


