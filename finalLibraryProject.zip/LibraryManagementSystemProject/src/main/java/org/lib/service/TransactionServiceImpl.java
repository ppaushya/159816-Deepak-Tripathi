package org.lib.service;

import java.util.List;

import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.dao.ITransactionDao;
import org.lib.dao.TransactionDaoImpl;

public class TransactionServiceImpl implements ITransactionService {

	
	ITransactionDao transactiondao = new TransactionDaoImpl(); 
	@Override
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid) {
	
		transactiondao.doTransaction(bookstransaction,regid);
		
		
	}

	@Override
	public int findfine(String userid) {
		
		return transactiondao.findfine(userid);
		
		
	}

	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration register) {
		// TODO Auto-generated method stub
		return transactiondao.getAllTransaction(register);
	}

	@Override
	public void calculateFine(BooksTransaction bookstransaction, String transId) {
		// TODO Auto-generated method stub
		transactiondao.calculateFine(bookstransaction,transId);
	}

	

	

}
