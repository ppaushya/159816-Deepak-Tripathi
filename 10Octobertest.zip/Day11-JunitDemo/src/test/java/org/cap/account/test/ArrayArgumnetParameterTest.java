package org.cap.account.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.cap.demo.Calculate;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class ArrayArgumnetParameterTest {
	
	Calculate calculate = new Calculate();
	private int[] input;
	private int output;
	public ArrayArgumnetParameterTest(int[] input,int output) {
		super();
		this.input = input;
		this.output = output;
	}
	
	
	
	
	@Parameters
	public static List<Object[]> getParameters()
	{
		return Arrays.asList(new Object[][] {
			{new int[] {1,2,3},6},
			{new int[] {1,2,3},6}
		});
	}
	
	@Test
	public void test()
	{
		assertEquals(output, calculate.addArray(input));
	}

}
