package org.cap.account.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.cap.demo.Calculate;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;



@RunWith(Parameterized.class)
public class ParameterizedTest {
	
	Calculate calculate = new Calculate();
		private int input1;
		private int input2;
		private int output;
	
		

		public ParameterizedTest(int input1, int input2, int output) {
			super();
			this.input1 = input1;
			this.input2 = input2;
			this.output = output;
		}
		
	
	@Parameters
	public static List<Object[]> getParameters(){
		return Arrays.asList(new Object [][] {
			{1,2,3},
			{1,3,4}
		});
	}
		
		@Test
		public void testmethod()
		{
			assertEquals(output, calculate.addNumber(input1, input2));
		}
		
		
	}




