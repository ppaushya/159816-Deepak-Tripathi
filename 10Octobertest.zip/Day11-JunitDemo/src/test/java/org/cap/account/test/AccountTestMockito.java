package org.cap.account.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.cap.account.dao.IAccountDao;
import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class AccountTestMockito {

	@Mock
	private IAccountDao accountDao;
	private IAccountService accountService;
	
	@Before
	public void Setup()
	{
		MockitoAnnotations.initMocks(this);
		accountService = new AccountServiceImpl(accountDao);
	}
	
	@Test
	public void test_create_method() throws InvalidAmountException
	{
		Customer customer=new Customer();
		customer.setCustomerId(1001);
		customer.setCustomerName("Tom");
		Address address=new Address();
		address.setAddressline("23,North Avvenue");
		customer.setAddress(address);
		Mockito.when(accountDao.addAccount(customer)).thenReturn(true);
		Account acc=accountService.createAccount(customer, 5000);
		
		Mockito.verify(accountDao).addAccount(customer);
		
		assertNotNull(acc);
		assertTrue(acc.getAccountNo()>0);
		assertEquals(5000, acc.getBalance(),0.0);
	}
	
	@Test
	public void test_deposit_Method()
	{
		Account account = new Account();
		account.setAccountNo(1001);
		account.setAccountType("Saving");
		account.setBalance(12000);
		
		Mockito.when(accountDao.findAccount(1001)).thenReturn(account);
		
		Account account2 = accountService.deposit(account, 3000);
		Mockito.verify(accountDao).findAccount(1001);
		assertEquals(15000, account2.getBalance(),0.0);
	}
	
	@Test
	public void test_withdraw_Method()
	{
		Account account = new Account();
		account.setAccountNo(1001);
		account.setAccountType("Saving");
		account.setBalance(12000);
		
		Mockito.when(accountDao.findAccount(1001)).thenReturn(account);
		
		Account account2 = accountService.withdraw(account, 3000);
		Mockito.verify(accountDao).findAccount(1001);
		assertEquals(9000, account2.getBalance(),0.0);
	}
	}
