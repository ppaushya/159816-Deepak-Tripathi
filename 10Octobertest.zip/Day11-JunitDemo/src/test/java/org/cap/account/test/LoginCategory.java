package org.cap.account.test;


//Marker Interface
public interface LoginCategory {

}
