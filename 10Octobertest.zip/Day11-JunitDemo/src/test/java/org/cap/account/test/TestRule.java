package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class TestRule {

	
	
	private IAccountService accserv= new AccountServiceImpl(null);
	@Rule
	
	public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void test() throws InvalidAmountException {
		
		thrown.expect(IllegalArgumentException.class);
		
		Customer customer=null;
		
	  accserv.createAccount(customer, 12000);	
		
		//fail("Not yet implemented");
	}

}
