package org.lib.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BooksTransaction {

	private String transaction_id;
	private BooksRegistration registration_id;
	private LocalDate issue_date;
	private LocalDate return_date;
	private int fine;
	public BooksTransaction() {
		super();
	}
	public BooksTransaction(String transaction_id, BooksRegistration registration_id, LocalDate issue_date,
			LocalDate return_date, int fine) {
		super();
		this.transaction_id = transaction_id;
		this.registration_id = registration_id;
		this.issue_date = issue_date;
		this.return_date = return_date;
		this.fine = fine;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public BooksRegistration getRegistration_id() {
		return registration_id;
	}
	public void setRegistration_id(BooksRegistration registration_id) {
		this.registration_id = registration_id;
	}
	public LocalDate getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(LocalDate issue_date) {
		this.issue_date = issue_date;
	}
	public LocalDate getReturn_date() {
		return return_date;
	}
	public void setReturn_date(LocalDate return_date) {
		this.return_date = return_date;
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	@Override
	public String toString() {
		return "BooksTransaction [transaction_id=" + transaction_id + ", registration_id=" + registration_id
				+ ", issue_date=" + issue_date + ", return_date=" + return_date + ", fine=" + fine + "]";
	}
	
	
	
}
