package org.cap.demo;

import java.util.Scanner;

public class EvenArray {
	
	public static void main(String []args)
	{
		 int n, c, d=0;
		    Scanner in = new Scanner(System.in);
		 
		    System.out.println("Input number of integers to sort");
		    n = in.nextInt();
		 
		    int array[] = new int[n];
		    
		    System.out.println("Enter " + n + " integers");
		 
		    for (c = 0; c < n; c++) 
		      array[c] = in.nextInt();
		    in.close();
		    

	    	System.out.println("Even Numbers : ");
		    for (c = 0; c < ( n ); c++) { 
			        if (array[c]%2==0) /* For descending order use < */
			        { 
			        System.out.println(array[c]);
			          d=d+array[c];
			        }
			      }
		    System.out.println("Sum of Even Numbers : "); 
		    System.out.println(d);
	}

}
