package org.cap.demo;

public class VarargsExample {
	
	public void printData( int ... arr)
	{
		for(int value: arr)
				System.out.println(value);
	}
	
public static void main(String[] args) {
		
		int[] num1= {1,2,3,4};
		
		VarargsExample dap = new VarargsExample();
		dap.printData(num1);
	}

}
