package org.cap.demo;

import java.util.Scanner;

public class EmployeeTest {
				Scanner scanner = new Scanner(System.in);
				int employeeId;
				String fname;
				String lname;
				int age;
				float salary;
				static EmployeeTest[] emp;
				
				public void getData()
				{
							System.out.println("Enter Employee ID");
						    employeeId = scanner.nextInt();
							System.out.println("Enter First Name:");
						    fname = scanner.next();
							System.out.println("Enter Last Name:");
							lname = scanner.next();
							System.out.println("Age");
							age = scanner.nextInt();
							System.out.println("Salary");
							salary = scanner.nextInt();
					
				}
				
				public void printData()
				{
							System.out.println(employeeId);
							System.out.println(fname);
							System.out.println(lname);
							System.out.println(age);
							System.out.println(salary);
					 
				}
				
				public static void SortbyEmployeeId()
				{
					   int  c, d, swap;
					    for (c = 0; c < ( emp.length - 1 ); c++) {
					      for (d = 0; d < emp.length - c - 1; d++) {
					        if (emp[d].employeeId > emp[d+1].employeeId) /* For descending order use < */
					        {
					          swap       = emp[d].employeeId;
					          emp[d].employeeId   = emp[d+1].employeeId;
					          emp[d+1].employeeId = swap;
					        }
					      }
					    }
					 
					    System.out.println("Sorted list of Employees");
					    
				}
				
				public static void main(String []args)
				{
					EmployeeTest[] emp = new EmployeeTest[3];
					for(int i=0;i<2;i++)
					{
						emp[i]=new EmployeeTest();
						
						emp[i].getData();
					}
					for(int i=0;i<2;i++)
					{
						
						emp[i].printData();
					}
				
					SortbyEmployeeId();
					
					for(int i=0;i<2;i++)
					{
						
						emp[i].printData();
					}
					
					 
					
				}
				
}
