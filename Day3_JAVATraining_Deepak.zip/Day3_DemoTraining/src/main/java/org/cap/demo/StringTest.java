package org.cap.demo;

import java.util.Scanner;

public class StringTest {
	
	String[] myStr;
	
	public void acceptString(int size)
	{
		Scanner scanner = new Scanner(System.in);
		myStr = new String[size];
		System.out.println("Enter " + size +" elements:");
		for (int i=0;i<size;i++)
		{
			myStr[i] = scanner.nextLine();
			
		}
		
		scanner.close();
	}
	 
	public void printString()
	{
		for(int i=0; i<myStr.length;i++)
		{
			System.out.println(myStr[i]);
		}
	}
	public static void main(String[] args) {
		StringTest str= new StringTest();
		str.acceptString(4);
		str.printString();

	}

}
