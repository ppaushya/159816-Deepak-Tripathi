package org.cap.demo;

public class DoubleArrayPassing {
	
	

	public int[] addArray(int[] arr1, int[] arr2)
	{
		int[] ans = new int[4];
		for(int i=0; i<4; i++)
			ans[i]=arr1[i] + arr2[i];
		
		return ans;
	}

	public static void main(String[] args) {
		
		int[] num1= {1,2,3,4};
		int[] num2= {10, 20, 30, 40};
		
		DoubleArrayPassing dap = new DoubleArrayPassing();
		int[] result = dap.addArray(num1, num2);
		for(int i=0; i<4; i++)
				System.out.println(result[i]);
	}

}
