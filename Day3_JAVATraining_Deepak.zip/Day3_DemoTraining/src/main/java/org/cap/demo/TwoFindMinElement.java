package org.cap.demo;

import java.util.Scanner;

public class TwoFindMinElement {
	
	  public static void main(String []args) 
			{
				int[][] arr1=new int[3][3];
				int[] arr2=new int[3];
				int d = 0, swap;
				MinimumArray two = new MinimumArray();
				Scanner scanner = new Scanner(System.in);
				System.out.println("Enter Rows");
				two.row = scanner.nextInt();
				System.out.println("Enter Columns");
				two.col = scanner.nextInt();
				
					for(int i=0; i<two.row; i++)
					{
						for(int j=0; j<two.col; j++)
						{
							arr1[i][j]=scanner.nextInt();
						}
						System.out.println();
					}
					for(int i=0; i<two.row; i++)
					{
						for(int j=0; j<two.col; j++)
						{
						    for (int c = 0; c < ( two.col - 1 ); c++) {
							      for (d = 0; d < two.col - c - 1; d++) {
							        if (arr1[i][d] > arr1[i][d+1]) /* For descending order use < */
							        {
							          swap       = arr1[i][d];
							          arr1[i][d]   = arr1[i][d+1];
							          arr1[i][d+1] = swap;
							        }
							      }
							    }
						  
						}
						System.out.println(arr1[i][0]+1);
						System.out.println();
					}
	
		 
		  }

}
