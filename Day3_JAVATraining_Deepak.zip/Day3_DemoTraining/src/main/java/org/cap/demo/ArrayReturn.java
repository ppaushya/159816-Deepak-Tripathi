package org.cap.demo;

public class ArrayReturn {
	
				public int[] getElements(int[] myArray)
				{
					int[] nums= new int[myArray.length];
					for(int i=0; i<nums.length;i++)
						{
							nums[i]= myArray[i] + 2;
						}
					return nums;
				}
				
				public void printElements(int[] myArray)
				{
					for(int i=0; i<myArray.length;i++)
							System.out.println(myArray[i] + " ");
				}
				
			public static void main(String[] args)
			{
				int[] nums = {12,24,323,232,0};
				ArrayReturn ary = new ArrayReturn();
				ary.getElements(nums);
				int[] testElements = new int[nums.length];
				testElements = ary.getElements(nums);
				ary.printElements(nums);
				ary.printElements(testElements);
			}
				
}
