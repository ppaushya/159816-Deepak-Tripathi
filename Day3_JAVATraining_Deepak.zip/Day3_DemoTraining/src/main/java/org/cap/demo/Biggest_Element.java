package org.cap.demo;

import java.util.Scanner;

public class Biggest_Element {
	
	int[] myArr;
	 
	public void getArrayElements(int size)
	{
 
		Scanner scr=new Scanner(System.in);
 
		myArr=new int[size];
		System.out.println("Enter " +size+"array elements");
		for(int i=0;i<size;i++)
		{
			myArr[i]=scr.nextInt();
		}
 
 
	}
 
	public void getBiggestElement(int[] a)
	{
		int max=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max)
				max=a[i];
		}
		System.out.println(max);
 
	}
 
	public void getSmallestElement(int[] a)
	{
		int min=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(min>a[i])
				min=a[i];
		}
		System.out.println(min);
	}
 
 
 
	public static void main(String[] args) {
		
		Biggest_Element obj=new Biggest_Element();
		obj.getArrayElements(5);
		obj.getSmallestElement(obj.myArr);
		obj.getBiggestElement(obj.myArr);
 
 
	}
 
}




