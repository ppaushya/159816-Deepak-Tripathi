package org.cap.demo;

public class TestArray {

	public static void main(String[] args) {

		int[] num= new int[10];
		short mynum = 90;
		num[0]=1;
		num[9]=mynum;
		num[1]=2;
		num[2]=3;
		num[3]=4;
		for(int i=0;i<10;i++)
		{
			System.out.println(num[i]);
		}

	}

}


