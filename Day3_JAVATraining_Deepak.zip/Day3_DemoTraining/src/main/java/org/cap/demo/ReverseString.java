package org.cap.demo;

import java.util.Scanner;

public class ReverseString {
	
	String[] myStr;
	
	public void acceptString(int size)
	{
		Scanner scanner = new Scanner(System.in);
		myStr = new String[size];
		System.out.println("Enter " + size +" elements:");
		for (int i=0;i<size;i++)
		{
			myStr[i] = scanner.nextLine();
			
		}
		
		scanner.close();
	}
	

	 
	public void printString()
	{
		   int i=0,j;
		   String temp;
	       j = i - 1;    
 
	       while(i<j)
	       {
	           temp = myStr[i];
	           myStr[i] = myStr[j];
	           myStr[j] = temp;
	           i++;
	           j--;
	       }System.out.print("Now the Reverse of Array is : \n");
	       for(i=0; i<5; i++)
	       {
	           System.out.print(myStr[i]+ "  ");
	       }   
	}

	
	public static void main(String[] args) {
		StringTest str= new StringTest();
		str.acceptString(5);
		str.printString();
	

	}

}
