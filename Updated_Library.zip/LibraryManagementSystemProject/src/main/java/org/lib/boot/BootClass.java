package org.lib.boot;

import java.util.List;
import java.util.Scanner;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.service.AddDeleteBookServiceImpl;
import org.lib.service.IAddDeleteBookService;
import org.lib.service.ILoginService;
import org.lib.service.IRegistrationService;
import org.lib.service.ITransactionService;
import org.lib.service.LoginServiceImpl;
import org.lib.service.RegistrationServiceImpl;
import org.lib.service.TransactionServiceImpl;
import org.lib.view.UserInteraction;

public class BootClass {



	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		ILoginService loginService = new LoginServiceImpl();
		IAddDeleteBookService adddeleteservice = new AddDeleteBookServiceImpl();
		IRegistrationService registrationService = new RegistrationServiceImpl();
		ITransactionService tranService = new TransactionServiceImpl();
		UserInteraction userInteraction = new UserInteraction();
		
		boolean stop = true;;

		do {   

			// FRONT END //
			System.out.println("--------------------------------------------------------");
			System.out.println("\tWelcome to Library");
			System.out.println("--------------------------------------------------------");

			System.out.println("Following Functionalities are available: \n");
			System.out.println("1- Login as a student");
			System.out.println("2- Login as a librarian");
			System.out.println("3- Exit");

			System.out.println("-----------------------------------------\n");        

			System.out.println("Enter Your Choice");
			int choice = 0;
			choice = scanner.nextInt();

			String userName,password;
			
			switch(choice){ 
			case 1:
				System.out.println("\nEnter User Name: ");  
				userName = scanner.next();
				System.out.println("\nEnter Password: ");
				password = scanner.next();

				if (userName == null){
					System.out.println("Please enter the user name! :)");
				}else if (password == null){
					System.out.println("Please enter the password! :)");
				}else if (loginService.validStudent(userName, password, 0)) {                    
					do {
						System.out.println("--------------------------------------------------------");
						System.out.println("\t  Welcome to Student's Portal");
						System.out.println("--------------------------------------------------------");
						System.out.println("These functionalities are available for Student: \n");
						System.out.println("1- List all books");
						System.out.println("2- Request a book to be issued");
						System.out.println("3- Check total fine");      
						System.out.println("4- Check if request is accepted"); 
						System.out.println("5- Logout");
						System.out.println("-------------------------------------------------------");

						List<BooksInventory> bookList = adddeleteservice.getallbooks();
						List<Users> usersList= loginService.getallusers(0);
						Users student = userInteraction.getUser(userName, usersList);
						BooksInventory selectedBook;
						//Users student = new Users();

						System.out.println("Enter your Choice");
						int ch = scanner.nextInt();
						switch(ch){
						case 1:
							userInteraction.printBooks(bookList);
							break;
						case 2:
							userInteraction.printBooks(bookList);
							selectedBook = userInteraction.findallbooks(bookList);
							
							if(selectedBook==null){
								System.out.println("Book not found!");
							}
							else{
								//System.out.println(userName);
								//student = userInteraction.getUser(userName, usersList);
								//System.out.println(student);
								registrationService.doRegistration(selectedBook, student, userInteraction.register(selectedBook, student));
							}

							break;
						case 3:	
							BooksRegistration bookRegistration = new BooksRegistration();
							//student = userInteraction.getUser(userName, usersList);
							
							
							List<BooksTransaction> bookTransactionList = tranService.getAllTransaction(student);
							userInteraction.printTransactions(bookTransactionList);
							String transactionId =  tranService.generateTransactionId();
							
							break;

						case 4:

							BooksRegistration bookRegistration1 = new BooksRegistration();
							BooksInventory book = new BooksInventory();
							
							

							
							List<BooksRegistration> bookregister = registrationService.getRegistration(student);
							
							userInteraction.printRegistrationRequest(bookregister);
							break;

						case 5:
							System.out.println("You have been logged out!!!");
							stop = false;
							
							break;
						default:
							System.out.println("Select [1|2|3|4|5]");
						}
					}while(stop);
				} else {
					System.out.println("Invalid login credentials!");
					//System.out.println("Do you want to login as another user?[true|false]");
				}
				break;

			case 2:
				System.out.println("\nEnter User Name: ");  
				userName = scanner.next();
				System.out.println("\nEnter Password: ");
				password= scanner.next();

				if (userName == null){
					System.out.println("Please enter the user name! :)");
				}else if (password == null){
					System.out.println("Please enter the password! :)");
				}else if (loginService.validLibrarian(userName, password, 1)){
					do {
						System.out.println("------------------------------------------------------------------");
						System.out.println("\t   Welcome to the Librarian's Portal");
						System.out.println("------------------------------------------------------------------");
						System.out.println("These functionalities are available for the librarian: \n");   
						System.out.println("1- List all book");
						System.out.println("2- Do you want to add new book?");
						System.out.println("3- Do you want to remove book?");  
						System.out.println("4- Check and confirm requests of a book");
						System.out.println("5- Input return date and do final transaction");                   
						System.out.println("6- Logout");
						System.out.println("--------------------------------------------------------");

						List<BooksInventory> booksList = adddeleteservice.getallbooks();
						List<Users> studentList = loginService.getallusers(0);
						
						System.out.println("Enter your Choice");
						int ch = scanner.nextInt();
						switch(ch){
						case 1:
							userInteraction.printBooks(booksList);
							break;
						case 2:
							adddeleteservice.addBook(userInteraction.getDetailsofBook());
							break;
						case 3:
							userInteraction.printBooks(booksList);
							System.out.println("Enter the Book you wish to delete!");
							String bookId =scanner.next();
							adddeleteservice.deleteBook(bookId);
							break;  
						case 4:
							BooksRegistration bookRegistration = new BooksRegistration();
							BooksInventory book = new BooksInventory();
							
							Users user = new Users();
							userInteraction.printStudents(studentList);
							System.out.println("Enter student Name");
							String studentName1 = scanner.next();
							user = userInteraction.getUser(studentName1, studentList);

							
							List<BooksRegistration> bookregister = registrationService.getRegistration(user);
							
							userInteraction.printRegistrationRequest(bookregister);
							System.out.println("Enter the registrationId for whom you want to issue a book");
							String register = scanner.next();
							bookRegistration  = userInteraction.getRegister(register, bookregister);
							String trans_id=tranService.generateTransactionId();
							tranService.doTransaction(userInteraction.transaction(bookRegistration,trans_id), bookRegistration);
							System.out.println("Your Registration has been done");
							registrationService.deleteRequest(register);
							break;
						case 5:
							Users user2 = new Users();
							BooksRegistration bookreg = new BooksRegistration();
							BooksTransaction booktransac = new BooksTransaction();
							
							userInteraction.printStudents(studentList);
							System.out.println("Enter student name");
							String studentName = scanner.next();
							Users student= userInteraction.getUser(studentName, studentList );
							

							List<BooksTransaction> booktrans1 = tranService.getAllTransaction(student);
							userInteraction.printTransactions(booktrans1);
							System.out.println("Enter Transaction_id");
							String trans_id1 = scanner.next();
							booktransac = userInteraction.getTransaction(trans_id1, booktrans1);
							tranService.calculateFine(userInteraction.calfine(booktransac), trans_id1);
							userInteraction.printTransactions(booktrans1);
							break;

						case 6:
							System.out.println("You have been logged out!!!");
							stop=false;
							
							break;
						default:
							System.out.println("Select [1|2|3|4|5|6]");
						}
						
					} while(stop);                   
				}
				else {
					System.out.println("Invalid login credentials!");
					//System.out.println("Do you want to login as another user?[true|false]");
				}
				break;


			case 3:
				stop = false; 
				break;
			default:
				System.out.println("Enter valid choice![1|2|3]");
			}
			System.out.println("Do you want to login as another user?[true|false]");
			stop = scanner.nextBoolean();
		}while(stop);
	}


}

