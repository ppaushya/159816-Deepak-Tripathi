package org.lib.bean;

import java.time.LocalDate;

public class BooksRegistration {

	private String registrationId;
	private BooksInventory bookId;
	private Users userId;
	private LocalDate registrationdate;
	public BooksRegistration() {
		super();
	}
	public BooksRegistration(String registration_id, BooksInventory book_id, Users user_id,
			LocalDate registrationdate) {
		super();
		this.registrationId = registration_id;
		this.bookId = book_id;
		this.userId = user_id;
		this.registrationdate = registrationdate;
	}
	public String getRegistration_id() {
		return registrationId;
	}
	public void setRegistration_id(String registration_id) {
		this.registrationId = registration_id;
	}
	public BooksInventory getBook_id() {
		return bookId;
	}
	public void setBook_id(BooksInventory book_id) {
		this.bookId = book_id;
	}
	public Users getUser_id() {
		return userId;
	}
	public void setUser_id(Users user_id) {
		this.userId = user_id;
	}
	public LocalDate getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(LocalDate registrationdate) {
		this.registrationdate = registrationdate;
	}
	@Override
	public String toString() {
		return "BooksRegistration [registration_id=" + registrationId + ", book_id=" + bookId + ", user_id=" + userId
				+ ", registrationdate=" + registrationdate + "]";
	}
	
	
}
