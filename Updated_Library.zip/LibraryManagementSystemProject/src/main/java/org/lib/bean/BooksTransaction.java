package org.lib.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BooksTransaction {

	private String transactionId;
	private BooksRegistration registrationId;
	private LocalDate issueDate;
	private LocalDate returnDate;
	private int fine;
	public BooksTransaction() {
		super();
	}
	public BooksTransaction(String transaction_id, BooksRegistration registration_id, LocalDate issue_date,
			LocalDate return_date, int fine) {
		super();
		this.transactionId = transaction_id;
		this.registrationId = registration_id;
		this.issueDate = issue_date;
		this.returnDate = return_date;
		this.fine = fine;
	}
	public String getTransaction_id() {
		return transactionId;
	}
	public void setTransaction_id(String transaction_id) {
		this.transactionId = transaction_id;
	}
	public BooksRegistration getRegistration_id() {
		return registrationId;
	}
	public void setRegistration_id(BooksRegistration registration_id) {
		this.registrationId = registration_id;
	}
	public LocalDate getIssue_date() {
		return issueDate;
	}
	public void setIssue_date(LocalDate issue_date) {
		this.issueDate = issue_date;
	}
	public LocalDate getReturn_date() {
		return returnDate;
	}
	public void setReturn_date(LocalDate return_date) {
		this.returnDate = return_date;
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	@Override
	public String toString() {
		return "BooksTransaction [transaction_id=" + transactionId + ", registration_id=" + registrationId
				+ ", issue_date=" + issueDate + ", return_date=" + returnDate + ", fine=" + fine + "]";
	}
	
	
	
}
