package org.lib.bean;

public class Users {
	
	private String userId;
	private String userName;
	private String password;
	private String emailId;
	private boolean librarian;
	public Users() {
		super();
	}
	
	
	public Users(String user_name, String password) {
		super();
		this.userName = user_name;
		this.password = password;
	}


	public Users(String userId, String user_name, String password, String email_id, boolean librarian) {
		super();
		this.userId = userId;
		this.userName = user_name;
		this.password = password;
		this.emailId = email_id;
		this.librarian = librarian;
	}
	public String getUser_id() {
		return userId;
	}
	public void setUser_id(String user_id) {
		this.userId = user_id;
	}
	public String getUser_name() {
		return userName;
	}
	public void setUser_name(String user_name) {
		this.userName = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail_id() {
		return emailId;
	}
	public void setEmail_id(String email_id) {
		this.emailId = email_id;
	}
	public boolean isLibrarian() {
		return librarian;
	}
	public void setLibrarian(boolean librarian) {
		this.librarian = librarian;
	}
	@Override
	public String toString() {
		return "Users [user_id=" + userId + ", user_name=" + userName + ", password=" + password + ", email_id="
				+ emailId + ", librarian=" + librarian + "]";
	}
	
	
	

}
