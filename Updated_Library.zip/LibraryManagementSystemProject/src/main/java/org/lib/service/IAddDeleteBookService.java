package org.lib.service;

import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;



public interface IAddDeleteBookService {
	
		public void addBook(BooksInventory booksinventory);
		public List<BooksInventory> getallbooks();
		public void deleteBook(String bookId);
		public String generateBookId();

}
