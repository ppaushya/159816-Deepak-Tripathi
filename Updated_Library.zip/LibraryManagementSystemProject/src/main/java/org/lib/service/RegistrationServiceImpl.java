package org.lib.service;

import java.util.List;
import java.util.Set;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.dao.IRegistrationDao;
import org.lib.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements IRegistrationService{

	
	IRegistrationDao regdao = new RegistrationDaoImpl();
	
	
	
	
	
	
	
	public RegistrationServiceImpl(IRegistrationDao regdao) {
		super();
		this.regdao = regdao;
	}

	public RegistrationServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books) {
		// TODO Auto-generated method stub
		return regdao.getRegistration(user, books);
	}

	@Override
	public boolean doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		 return regdao.doRegistration(books, user, register);
		
	}

	@Override
	public void deleteRequest(String resitrationId) {
		regdao.deleteRequest(resitrationId);
		
	}

	@Override
	public String generateRegistrationId() {
		return regdao.generateRegistrationId();
	}

	@Override
	public List<BooksRegistration> getRegistration(Users user) {
		// TODO Auto-generated method stub
		return regdao.getRegistration(user);
	}

	@Override
	public void deleteRequest(BooksTransaction booktransac) {
		// TODO Auto-generated method stub
		regdao.deleteRequest(booktransac);
	}

}
