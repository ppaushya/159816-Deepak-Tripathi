package org.lib.test;

import org.junit.Before;
import org.junit.Test;
import org.lib.bean.Users;
import org.lib.dao.LoginDaoImpl;
import org.lib.service.LoginServiceImpl;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class LoginTest {
	
	
	@Mock
    private LoginDaoImpl logindao;
	
	private LoginServiceImpl loginservices;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		loginservices= new LoginServiceImpl(logindao);
	}
	

	
	@Test
	
	public void test_acc_with_alllogin_format()
	{
	  
	   
	   Mockito.when(logindao.isValidLibrarian("Deepak", "123456", 1)).thenReturn(true);
	   
	   loginservices.validLibrarian("Deepak", "123456", 1);
	   
	   
	   Mockito.verify(logindao).isValidLibrarian("Deepak", "123456", 1);
	   
	   
	   
	}
	
	
	
}


	 
 
