package org.cap.demo;

public class SwitchDemo {
					
	
	public static void main(String[] args) {
		int num=10;
		switch(num)
		{
		case 1:
			System.out.println("One");
			System.out.println("Block");
			break;
			
		case 2:
			System.out.println("Two");
			System.out.println("OO");
			break;
			
		case 3:
			System.out.println("Three");
			System.out.println("Finish");
			break;
			
			default:
				System.out.println("default Block");
		}
	}
}
