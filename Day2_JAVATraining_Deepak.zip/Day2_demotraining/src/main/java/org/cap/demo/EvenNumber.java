package org.cap.demo;

public class EvenNumber {

	public static void main(String args[]){  
	   
		System.out.println("Even Numbers:");  
		for(int i=0;i<100;i++){  
			
		
					if(i%2==0){  
						
					System.out.print(i);  
							  }  
		}  
	}
}
