package org.cap.demo;

public class SwitchDemoLong {

	public static void main(String[] args) {
		//Long is not accepted
		 int num  = 2000; 
	        switch(num) 
	        { 
	            case 1: 
	                System.out.println("one"); 
	                break; 
	            case 2000000000: 
	                System.out.println("two"); 
	                break; 
	            case 5: 
	                System.out.println("three"); 
	                break; 
	            default: 
	                System.out.println("no match"); 
	        }

	}

}
