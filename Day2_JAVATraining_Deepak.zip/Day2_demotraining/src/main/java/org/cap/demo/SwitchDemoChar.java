package org.cap.demo;

import java.util.Scanner;

public class SwitchDemoChar {
	  static Scanner scanner = new Scanner(System.in);

	  public static void main(String[] args) {
	    System.out.print("Enter the package code: ");
	    String s = scanner.next();
	    char p = s.charAt(0);

	    String details = "";

	    switch (p) {
	    case 'E':
	    case 'e':
	      details += "Deepak";
	    case 'D':
	    case 'd':
	      details += "Tripathi";
	    case 'C':
	    case 'c':
	      details += "Mohit";
	    case 'B':
	    case 'b':
	      details += "Sinha";
	    case 'A':
	    case 'a':
	      details += "Sneha";
	      break;
	    default:
	      details = "That's";
	      break;
	    }
	    System.out.println(details);
	  }

}
