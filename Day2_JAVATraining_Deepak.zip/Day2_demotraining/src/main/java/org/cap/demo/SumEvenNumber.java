package org.cap.demo;

public class SumEvenNumber {
	
	public static void main(String args[]){  
		 
		int j=0;
		System.out.println("Even Numbers Sum:");  
		for(int i=0;i<100;i++){  
			
		
					if(i%2==0){  
						
						j=j+i;
					  
							  }  
		}
		System.out.print(j);
	}

}
