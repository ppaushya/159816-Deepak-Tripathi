package org.cap.demo;

public class TestClass {
	
	public void Testif (int num)
	{
		if(num>0)
			System.out.println("Positive");
		else if(num==0)
			System.out.println("Zero");
		else if(num<0)
			System.out.println("Negative");
	}
	public static void main(String[] args)
	{
		TestClass class1 = new TestClass();
		class1.Testif(0);
	}
}
