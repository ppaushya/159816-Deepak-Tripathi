package org.cap.demo;

public class EvenNewFashion {
	public static void main(String args[]){  
		 
		System.out.println("Even Numbers Fashion:");  
		for(int i=1;i<=100;i++){  
					if(i%2==0){  
			
						System.out.print(i+",");
							  }  
					 if(i%10==0)
					 {
						 System.out.print("\n");
					 }
		}
	}


}
