package org.cap.demo;

import java.util.Scanner;

public class Product {
	
			String productName;
			int productId;
			int quantity;
			float Margin_price;
			int discount;
			float tax;
			
			public void productData()
			{
				Scanner scanner = new Scanner(System.in);
				System.out.println("Enter productName:");
				productName = scanner.next();
				System.out.println("Enter productId:");
				productId = scanner.nextInt();
				System.out.println("quantity");
				quantity = scanner.nextInt();
				System.out.println("Margin_price");
				Margin_price = scanner.nextFloat();
				System.out.println("discount%:");
				discount = scanner.nextInt();
				scanner.close();
				
			}
			 public float discountCalculation()
			 {
				 return (Margin_price*quantity*discount/100);
				 
			 }
			 public float taxCalculation()
			 {
				 if(discount > 90)
					 tax=1;
				 if(discount <= 90 && discount > 80 )
					 tax=12;
				 if(discount <= 80 && discount > 60 )
					 tax=20;
				 if(discount <= 60 && discount > 50 )
					 tax=25;
				 if(discount <= 50)
					 tax=40;
				 return (Margin_price*quantity*tax/100);
				 
			 }
			 public float priceCalculation()
			 {
				 return (Margin_price*quantity-(Margin_price*quantity*discount/100)+(Margin_price*quantity*tax/100));
				 
			 }

	public static void main(String[] args) {
	
		Product obj = new Product();
		obj.productData();
		System.out.println("Discount:" + obj.discountCalculation());
		System.out.println("Tax:" + obj.taxCalculation());
		System.out.println("Final_Price:" + obj.priceCalculation());
		
	}

}
