package com.capgemini.assignment;

public class Question3 {
	
    public static boolean isPrime(int num) {
        boolean flag = true;

        for(int i = 2; i <= num/2; ++i) {

            if(num % i == 0) {
                flag = false;
                break;
            }
        }

        return flag;
    }

    public static void main(String[] args) {

        int l = 1, h = 1000;
        System.out.println("Prime Numbers");
        while (l < h) {
            if(isPrime(l))
                System.out.print(l + " ");

            ++l;
        }
    }



}
