package com.capgemini.assignment;

import java.util.Scanner;

public class Question2 {
	
	int num;
	
	public void getData() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter input");
		num = scanner.nextInt();
		scanner.close();
	}
	
	public void sumDigit()
	{
		int j = 0;
		for(int i=0;i<=num;i++){  
			
				j=j+i;
			  
	}
	System.out.print(j);
	}
	
	public static void main(String[] args)
	{
		
		Question2 ques2 = new Question2();
		ques2.getData();
		ques2.sumDigit();
}
}
