package com.capgemini.assignment;

import java.util.Scanner;

public class Question5 {


	 public static void main (String[] args)
	   {	
		 String choice;
		 Scanner scanner = new Scanner(System.in);
			System.out.print("Enter the string");
			choice = scanner.next();
			scanner.close();
			char[] chars = choice.toCharArray();
		    for(int i=0; i < choice.length(); i++)
		    {
		    	 for(int j=0; j < i; j++)
		    	 {
		    	      System.out.print(chars[j] +" ");
		    	 }
		    	 System.out.println();
		    }
		     
	    
	   }	
}
