package com.capgemini.assignment;

import java.util.Scanner;

public class Question4 {
	
	
		public void isArmstrong(int n)
		{
		    int c=0,a,temp, k=n;  
		    temp=n;  
		    while(n>0)  
		    {  
		    a=n%10;  
		    n=n/10;  
		    c=c+(a*a*a);  
		    }  
		    if(temp==c)  
		    	System.out.println("Armstrong number:" + k);  
		    else
		    	System.out.println("Not a Armstrong number:" + k);
		}
	

	 public static void main (String[] args)
	   {	
		 int num;
		 Scanner scanner = new Scanner(System.in);
			System.out.print("Enter input");
			num = scanner.nextInt();
			scanner.close();
		    Question4 ques4 = new Question4();
		     ques4.isArmstrong(num);
	    
	   }

}
