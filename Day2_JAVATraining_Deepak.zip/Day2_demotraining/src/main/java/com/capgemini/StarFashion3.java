package com.capgemini;

public class StarFashion3 {
	
	public static void main(String[] args) {
	
			    int r = 4, i, k, num=1, j;
				
				for(i=0;i<r;i++)
				{
					for(k=r; k>i; k--)
					{
						System.out.print(" ");
					}
		            num = 1;
					for(j=0;j<=i;j++)
					{
						 System.out.print(num+ " ");
		                 num = num * (i - j) / (j + 1);
					}
					System.out.println();
				}
			

}
}
