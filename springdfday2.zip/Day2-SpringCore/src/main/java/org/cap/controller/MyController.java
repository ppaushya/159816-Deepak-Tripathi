package org.cap.controller;

import org.cap.modal.LoginPojo;
import org.cap.modal.Register;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

@Controller
public class MyController {

	@Autowired
	private ILoginService loginservice;

	@RequestMapping("/")
	public ModelAndView getIndexPage(){
		return new ModelAndView("index", "login", new LoginPojo());
	}

	@RequestMapping("/validate")
	public String validateLogin(ModelMap map,
			@ModelAttribute("login") LoginPojo loginpojo) {

		if(loginservice.isValidLogin(loginpojo))
		{
			map.addAttribute("register",new Register());
			return "register";
		}
		else
		{
			return "redirect:/";
		}
	}

}
