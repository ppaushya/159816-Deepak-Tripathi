package org.cap.service;

import org.cap.modal.LoginPojo;
import org.springframework.stereotype.Service;

@Service("loginservice")
public class LoginServiceIMpl implements ILoginService {

	@Override
	public boolean isValidLogin(LoginPojo loginpojo) {
		
		if(loginpojo.getUserName().equals("tom") && loginpojo.getUserPassword().equals("tom123") ) {
			return true;
		}
		return false;
	}

}
