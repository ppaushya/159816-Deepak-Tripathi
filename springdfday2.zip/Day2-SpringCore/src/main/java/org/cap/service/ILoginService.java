package org.cap.service;

import org.cap.modal.LoginPojo;

public interface ILoginService {
	
	public boolean isValidLogin(LoginPojo loginpojo);

}
