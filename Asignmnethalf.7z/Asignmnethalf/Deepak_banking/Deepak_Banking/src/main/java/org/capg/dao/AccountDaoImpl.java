package org.capg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao {
	
	
	 Set<Account> accounts = new HashSet();
	
	

	@Override
	public Set<Account> getAllAccounts() {
		return accounts;
	}

	@Override
	public void createAccount(Account account) {
		
		accounts.add(account);
		
	}

}
