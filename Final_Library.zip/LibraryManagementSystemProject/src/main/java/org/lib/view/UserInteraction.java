package org.lib.view;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.service.AddDeleteBookServiceImpl;
import org.lib.service.IAddDeleteBookService;
import org.lib.service.IRegistrationService;
import org.lib.service.RegistrationServiceImpl;

import java.time.temporal.ChronoUnit;

public class UserInteraction {
	
	 Scanner scanner = new Scanner(System.in);
	 BooksInventory book = new BooksInventory();
	 BooksRegistration register = new BooksRegistration();
	 BooksTransaction trans = new BooksTransaction();
	 Users user = new Users();
	
	
	public void printBooks(List<BooksInventory> books)
	{
		System.out.println("BookID\tBookName\t"
				+ "Author1\t\tAuthor2\t  Publisher\t  YearofPublisher");
		System.out.println("------------------------------------------------------------------------------------");

		for(BooksInventory book:books)
		{
			System.out.println(book.getBookId()+"\t"+"   "+book.getBookName()+"\t"+"         "+
					book.getAuthor1()+"\t"+"         "+book.getAuthor2()+"\t"+"         "+book.getPublisher()+"\t   "+
					book.getYearOfPublication());
		}
	}
	
	
	
	public void printRegistrationRequest(List<BooksRegistration> registers, Users user, BooksInventory book)
	{
		System.out.println("RegistrationID\t  RegistrationDate\t");
		System.out.println("-----------------------------------------------------------------");

		for(BooksRegistration register:registers)
		{
			System.out.println(register.getRegistrationId()+"\t"+user.getUserId()+"  "+book.getBookId()+"\t "+"    "+register.getRegistrationdate());
		}
	}
	
	public void printRegistrationRequest(List<BooksRegistration> registers)
	{
		System.out.println("RegistrationID\t  RegistrationDate\t");
		System.out.println("-----------------------------------------------------------------");

		for(BooksRegistration register:registers)
		{
			System.out.println(register.getRegistrationId()+"\t"+"\t "+"    "+register.getRegistrationdate());
		}
	}
	
	public void printTransactions(List<BooksTransaction> transactions)
	{
		System.out.println("TransactionID\tIssueDate\t"+"RegistrationId"+"\t"
				+ "ReturnDate\tFine");
		System.out.println("-----------------------------------------------------------------");

		for(BooksTransaction transaction:transactions)
		{
			System.out.println(transaction.getTransactionId()+"\t"+" \t"+transaction.getIssueDate()+"\t"+transaction.getRegistrationId().getRegistrationId()+"\t"+transaction.getReturnDate()+"\t"+"   "+transaction.getFine());
		}
	}
	
	public BooksInventory findallbooks(List<BooksInventory> books)
	{

		
		System.out.println("Enter your Book_Id");
		String Book_Id;
		Book_Id=scanner.next();

		for(BooksInventory book : books)
		{
			
			if(Book_Id.equals(book.getBookId()))
			{
				return book;
			}

		}

		return null;
		}
	
	
	public BooksInventory getBook(String book_id, List<BooksInventory> books)
	{
		for(BooksInventory book:books)
		{
			if(book.getBookId().equals(book_id))
				return book;
		}
		System.out.println("Enter valid Book ID!");
		return null;
	}
	
	public Users getUser(String userName, List<Users> users)
	{
		for(Users user:users)
		{
			if(user.getUserName().equals(userName))
				return user;
		}
		return null;
	}
	
	public BooksRegistration getRegister(String reg_id, List<BooksRegistration> registers)
	{
		
		for(BooksRegistration register:registers)
		{
				if(register.getRegistrationId().equals(reg_id))
				return register;
		}
		System.out.println("Enter valid Registration ID!");
		return null;
	}
	
	
	public BooksTransaction getTransaction(String trans_id, List<BooksTransaction> transactions)
	{
		for(BooksTransaction transaction:transactions)
		{
			if(transaction.getTransactionId().equals(trans_id))
				return transaction;
		}
		System.out.println("Enter valid Transaction ID!");
		return null;
	}
	
	public BooksRegistration register(BooksInventory bookId , Users userId)
	{	
		
		
		System.out.println("You can register by filling details");
		IRegistrationService regser = new RegistrationServiceImpl();
		String reg_id= regser.generateRegistrationId();
		register.setRegistrationId(reg_id);
		register.setBookId(bookId);
		register.setUserId(userId);
		LocalDate reg_date = LocalDate.now();
		System.out.println("Your registration date : "+reg_date);
		register.setRegistrationdate(reg_date);
		
		
		return register;
	}
	
	
	
	public BooksInventory getDetailsofBook()
	{
		/*System.out.println("Enter Book Id");
		String book_id = scanner.next();*/
		IAddDeleteBookService addDelete=new AddDeleteBookServiceImpl();
		String book_id=addDelete.generateBookId();
		book.setBookId(book_id);
		System.out.println("Enter Book Name");
		String book_name = scanner.next();
		book.setBookName(book_name);
		System.out.println("Enter Book Author 1");
		String author1 = scanner.next();
		book.setAuthor1(author1);
		System.out.println("Enter Book Author 2");
		String author2 = scanner.next();
		book.setAuthor2(author2);
		System.out.println("Enter Book Publisher");
		String publisher = scanner.next();
		book.setPublisher(publisher);
		System.out.println("Enter Book Year of Publishing");
		String yearofpub = scanner.next();
		book.setYearOfPublication(yearofpub);
		
		return book;
		
	}
	
	public BooksTransaction transaction(BooksRegistration bookreg, String trans_id)
	{	
		System.out.println("You can do transaction by entering transaction_id");
		trans.setTransactionId(trans_id);
		trans.setRegistrationId(bookreg);
		LocalDate issue_date = bookreg.getRegistrationdate();
		System.out.println("Your issue date is: "+issue_date);
		trans.setIssueDate(issue_date);
		LocalDate return_date = issue_date.plusDays(14);
		trans.setReturnDate(return_date);
		trans.setFine(0);
		return trans;
	}
	
	public BooksTransaction calculateFine( BooksTransaction transaction)
	{
		
		LocalDate issue_date = transaction.getIssueDate();
		System.out.println("Enter return date by the student");
		System.out.println("Enter year");
		int year =scanner.nextInt();
		System.out.println("Enter month");
		int month =scanner.nextInt();
		System.out.println("Enter day");
		int dayOfMonth =scanner.nextInt();
		
		LocalDate actualreturndate = LocalDate.of(year, month, dayOfMonth);
		System.out.println("Your return date: "+actualreturndate);
		trans.setReturnDate(actualreturndate);
		
		long daysBetween = ChronoUnit.DAYS.between(issue_date, actualreturndate);
		
		if(daysBetween==14 || daysBetween<14)
		{
			int fine = 0;
			trans.setFine(fine);
		}
		else{
			int fine = (int) ((daysBetween-14)*1);
			trans.setFine(fine);
			System.out.println("Your fine: "+fine);
		}
		return trans;
	}



	public void printStudents(List<Users> studentList) {
		System.out.println("UserID\tUserName\t");
				
		System.out.println("------------------------------------------------------------------------------------");

		for(Users student:studentList)
		{
			System.out.println(student.getUserId()+"\t"+"   "+student.getUserName());
		}
	}

}

