package org.lib.bean;

import java.time.LocalDate;

public class BooksTransaction {

	private String transactionId;
	private BooksRegistration registrationId;
	private LocalDate issueDate;
	private LocalDate returnDate;
	private int fine;
	public BooksTransaction() {
		super();
	}
	public BooksTransaction(String transaction_id, BooksRegistration registration_id, LocalDate issue_date,
			LocalDate return_date, int fine) {
		super();
		this.transactionId = transaction_id;
		this.registrationId = registration_id;
		this.issueDate = issue_date;
		this.returnDate = return_date;
		this.fine = fine;
	}
	
	@Override
	public String toString() {
		return "BooksTransaction [transaction_id=" + transactionId + ", registration_id=" + registrationId
				+ ", issue_date=" + issueDate + ", return_date=" + returnDate + ", fine=" + fine + "]";
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public BooksRegistration getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(BooksRegistration registrationId) {
		this.registrationId = registrationId;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	
}
