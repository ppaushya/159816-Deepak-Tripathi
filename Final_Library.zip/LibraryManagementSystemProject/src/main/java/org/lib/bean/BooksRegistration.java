package org.lib.bean;

import java.time.LocalDate;

public class BooksRegistration {

	private String registrationId;
	private BooksInventory bookId;
	private Users userId;
	private LocalDate registrationdate;
	public BooksRegistration() {
		super();
	}
	public BooksRegistration(String registration_id, BooksInventory book_id, Users user_id,
			LocalDate registrationdate) {
		super();
		this.registrationId = registration_id;
		this.bookId = book_id;
		this.userId = user_id;
		this.registrationdate = registrationdate;
	}
	
	@Override
	public String toString() {
		return "BooksRegistration [registration_id=" + registrationId + ", book_id=" + bookId + ", user_id=" + userId
				+ ", registrationdate=" + registrationdate + "]";
	}
	public String getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(String registrationId) {
		this.registrationId = registrationId;
	}
	public BooksInventory getBookId() {
		return bookId;
	}
	public void setBookId(BooksInventory bookId) {
		this.bookId = bookId;
	}
	public Users getUserId() {
		return userId;
	}
	public void setUserId(Users userId) {
		this.userId = userId;
	}
	public LocalDate getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(LocalDate registrationDate) {
		this.registrationdate = registrationDate;
	}
	
	
}
