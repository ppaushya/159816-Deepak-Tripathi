package org.lib.bean;

public class BooksInventory {
	
	private String bookId;
	private String bookName;
	private String author1;
	private String author2;
	private String publisher;
	private String yearOfPublication;
	public BooksInventory() {
		super();
	}
	public BooksInventory(String book_id, String book_name, String author1, String author2, String publisher,
			String yearofpub) {
		super();
		this.bookId = book_id;
		this.bookName = book_name;
		this.author1 = author1;
		this.author2 = author2;
		this.publisher = publisher;
		this.yearOfPublication = yearofpub;
	}
	
	@Override
	public String toString() {
		return "BooksInventory [book_id=" + bookId + ", book_name=" + bookName + ", author1=" + author1 + ", author2="
				+ author2 + ", publisher=" + publisher + ", yearofpub=" + yearOfPublication + "]";
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearOfPublication() {
		return yearOfPublication;
	}
	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	

}
