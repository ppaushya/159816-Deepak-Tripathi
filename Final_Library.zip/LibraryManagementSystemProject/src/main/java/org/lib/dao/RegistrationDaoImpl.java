package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public class RegistrationDaoImpl implements IRegistrationDao{


	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/lms", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}

		return null;

	}

	@Override
	public List<BooksRegistration> getRegistration(Users user , BooksInventory books) {
		List<BooksRegistration> registers =new ArrayList<>();
		String str="select * from BooksRegistration where user_id="+user.getUserId()+";";
		String str1 ="select * from users";
		String str2 = "select * from booksinventory";
		try(Connection connection=getDbConnection())
		{
			BooksInventory book = new BooksInventory();
			Users userid = new Users();
			PreparedStatement statement=connection.prepareStatement(str);
			PreparedStatement statement1=connection.prepareStatement(str1);
			PreparedStatement statement2=connection.prepareStatement(str2);

			ResultSet rs= statement.executeQuery();
			ResultSet rs1= statement1.executeQuery();
			ResultSet rs2= statement2.executeQuery();


			while(rs2.next()){

				book.setBookId(rs2.getString(1));

			}

			while(rs1.next()){
				userid.setUserId(rs1.getString(1));
			}

			while(rs.next()){
				BooksRegistration reg =new BooksRegistration();
				reg.setRegistrationId(rs.getString(1));
				reg.setRegistrationdate(rs.getDate(4).toLocalDate());
				registers.add(reg);	

			}
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return registers;
	}

	@Override
	public boolean doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		String sql="insert into BooksRegistration values(?,?,?,?);";

		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);

			statement.setString(1, register.getRegistrationId());
			statement.setString(2, register.getBookId().getBookId());
			statement.setString(3, register.getUserId().getUserId());
			statement.setDate(4, java.sql.Date.valueOf(register.getRegistrationdate()));

			int row=statement.executeUpdate();

			if(row>0) {
				System.out.println("Your book has been registerd and forwarded to librarian!");
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

	@Override
	public void deleteRequest(String resitrationId) {
		String sql1 = "SET foreign_key_checks = 0";
		String sql="delete from booksregistration where registration_id = ?";
		String sql2 = "SET foreign_key_checks = 1";
		try(Connection conn = getDbConnection()){


			PreparedStatement pst1=conn.prepareStatement(sql1);
			pst1.executeQuery();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, resitrationId);
			int row = pst.executeUpdate();

			if(row<0){
				System.out.println("Registration request has not been deleted");
			}
			else{
				System.out.println("Registration request has been deleted");
			}


			PreparedStatement pst2=conn.prepareStatement(sql2);
			pst2.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		}


	}

	@Override
	public String generateRegistrationId() {
		String sql = "select * from booksRegistration";
		try(Connection connection=getDbConnection()){

			PreparedStatement statement=connection.prepareStatement(sql);
			ResultSet rs= statement.executeQuery();

			String regId=new String("99");
			while(rs.next()){
				regId=rs.getString(1);
			}
			return String.valueOf((Long.parseLong(regId)+1));
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BooksRegistration> getRegistration(Users user) {
		List<BooksRegistration> registers =new ArrayList<>();
		IAddDeleteBookDao addDelete=new AddDeleteBookDaoImpl();
		ILoginDao loginDao=new LoginDaoImpl();
		String str="select * from BooksRegistration where user_id=?;";
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setString(1, user.getUserId());

			ResultSet rs= statement.executeQuery();
			while(rs.next()){
				BooksRegistration reg =new BooksRegistration();
				reg.setRegistrationId(rs.getString(1));
				reg.setBookId(addDelete.getBook(rs.getString(2)));
				reg.setUserId(loginDao.getBook(rs.getString(2)));
				reg.setRegistrationdate(rs.getDate(4).toLocalDate());
				registers.add(reg);	
			}
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return registers;
	}

	@Override
	public BooksRegistration getRegistration(String string) {
		BooksRegistration booksRegistration=new BooksRegistration();
		IAddDeleteBookDao addDelete=new AddDeleteBookDaoImpl();
		ILoginDao loginDao=new LoginDaoImpl();
		String str="select * from BooksRegistration where registration_id=?;";
		try(Connection connection=getDbConnection()){
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setString(1, string);

			ResultSet rs= statement.executeQuery();

			BooksRegistration reg =new BooksRegistration();
			if(rs.next()){
				reg.setRegistrationId(rs.getString(1));
				reg.setBookId(addDelete.getBook(rs.getString(2)));
				reg.setUserId(loginDao.getBook(rs.getString(2)));
				reg.setRegistrationdate(rs.getDate(4).toLocalDate());
			}
			return reg;
		}	catch (SQLException e) {
			e.printStackTrace();
		}
		return booksRegistration;
	}

	@Override
	public void deleteRequest(BooksTransaction bookTransaction) {
		String sql1 = "SET foreign_key_checks = 0";
		String sql="delete from booksregistration where registration_id = (select registration_id from booksTransaction where transaction_id=?)";
		String sql2 = "SET foreign_key_checks = 1";
		try(Connection conn = getDbConnection()){


			PreparedStatement pst1=conn.prepareStatement(sql1);
			pst1.executeQuery();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, bookTransaction.getTransactionId());
			int row = pst.executeUpdate();

			if(row<0){
				System.out.println("Registration request has not been deleted");
			}
			else{
				System.out.println("Registration request has been deleted");
			}


			PreparedStatement pst2=conn.prepareStatement(sql2);
			pst2.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
