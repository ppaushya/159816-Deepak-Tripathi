package org.lib.dao;

import java.util.List;

import org.lib.bean.BooksInventory;

public interface IAddDeleteBookDao {
	
	public void addBook(BooksInventory booksinventory);
	public void deleteBook(String bookId);
	public String generateBookId();
	public BooksInventory getBook(String string);
	List<BooksInventory> getAllBooks();

}
