package org.lib.service;

import java.util.List;
import org.lib.bean.Users;


public interface ILoginService {
	
	public boolean isValidStudent(String userName, String password, int c);
	public boolean isValidLibrarian(String userNameLib, String passwordLib, int c);
	public List<Users> getAllUsers();
	public List<Users> getAllUsers(int i);
}
