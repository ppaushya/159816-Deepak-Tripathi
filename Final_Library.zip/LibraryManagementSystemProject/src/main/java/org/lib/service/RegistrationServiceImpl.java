package org.lib.service;

import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;
import org.lib.dao.IRegistrationDao;
import org.lib.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements IRegistrationService{

	
	IRegistrationDao registrationDao = new RegistrationDaoImpl();
	
	public RegistrationServiceImpl(IRegistrationDao regdao) {
		super();
		this.registrationDao = regdao;
	}

	public RegistrationServiceImpl() {

	}

	@Override
	public List<BooksRegistration> getRegistration(Users user, BooksInventory books) {
		return registrationDao.getRegistration(user, books);
	}

	@Override
	public boolean doRegistration(BooksInventory books, Users user, BooksRegistration register) {
		 return registrationDao.doRegistration(books, user, register);
		
	}

	@Override
	public void deleteRequest(String resitrationId) {
		registrationDao.deleteRequest(resitrationId);
		
	}

	@Override
	public String generateRegistrationId() {
		return registrationDao.generateRegistrationId();
	}

	@Override
	public List<BooksRegistration> getRegistration(Users user) {
		return registrationDao.getRegistration(user);
	}

	@Override
	public void deleteRequest(BooksTransaction bookTransaction) {
		registrationDao.deleteRequest(bookTransaction);
	}

	
}
