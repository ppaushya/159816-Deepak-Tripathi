package org.lib.service;

import java.util.List;

import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public interface ITransactionService {

	public boolean doTransaction(BooksTransaction bookstransaction, BooksRegistration bookreg);
	public int findFine(String userid);
	public List<BooksTransaction> getAllTransaction(BooksRegistration register);
	public void calculateFine(BooksTransaction bookstransaction, String transId);
	public String generateTransactionId();
	public List<BooksTransaction> getAllTransaction(Users student);
	
}
