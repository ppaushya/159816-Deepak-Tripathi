package org.lib.service;

import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.exceptions.BookNotFoundException;



public interface IAddDeleteBookService {
	
		public void addBook(BooksInventory booksInventory);
		public List<BooksInventory> getAllBooks();
		public void deleteBook(String bookId) throws BookNotFoundException;
		public String generateBookId();

}
