package org.lib.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.lib.bean.BooksInventory;
import org.lib.dao.AddDeleteBookDaoImpl;
import org.lib.dao.IAddDeleteBookDao;
import org.lib.exceptions.BookNotFoundException;


public class AddDeleteBookServiceImpl implements IAddDeleteBookService {
	
	public final static Logger logger=Logger.getLogger(LoginServiceImpl.class);

	IAddDeleteBookDao addDelete= new AddDeleteBookDaoImpl();

	@Override
	public void addBook(BooksInventory booksInventory) {
		addDelete.addBook(booksInventory);
		
	}

	@Override
	public List<BooksInventory> getAllBooks() {
		return addDelete.getAllBooks();
	}

	@Override
	public void deleteBook(String bookId){
		boolean x=false;
		List<BooksInventory> booksList=addDelete.getAllBooks();
		for(BooksInventory book:booksList) {
			if(bookId.equals(book.getBookId())) 
				x=true;
		}
		if(!x) {
			logger.error("Book id not found!");
			try {
				throw new BookNotFoundException("Book id not found!");
			} catch (BookNotFoundException e) {
				e.printStackTrace();
			}
		}
		else
			addDelete.deleteBook(bookId);

	}

	@Override
	public String generateBookId() {
		return addDelete.generateBookId();
	}

	

}
