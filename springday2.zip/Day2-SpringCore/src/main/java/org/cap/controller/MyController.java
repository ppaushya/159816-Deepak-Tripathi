package org.cap.controller;

import org.cap.modal.LoginPojo;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

@Controller
public class MyController {

	@Autowired
	private ILoginService loginservice;

	@RequestMapping("/")
	public ModelAndView getIndexPage(){
		return new ModelAndView("index", "login", new LoginPojo());
	}

	@RequestMapping("/validate")
	public String validateLogin(@ModelAttribute("login") LoginPojo loginpojo) {

		if(loginservice.isValidLogin(loginpojo))
		{
			return "success";
		}
		else
		{
			return "redirect:/";
		}
	}

}
