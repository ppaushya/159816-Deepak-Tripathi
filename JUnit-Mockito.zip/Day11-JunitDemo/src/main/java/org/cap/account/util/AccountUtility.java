package org.cap.account.util;

public class AccountUtility {
	
	public static int generateAccountNo() {
		return (int)(Math.random()*1000);
	}

}
