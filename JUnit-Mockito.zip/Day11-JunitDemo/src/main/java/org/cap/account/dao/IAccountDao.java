package org.cap.account.dao;

import org.cap.account.model.Account;
import org.cap.account.model.Customer;

public interface IAccountDao {

	public boolean addAccount(Customer customer);
	
	public Account findAccount(int accountNo);
}
