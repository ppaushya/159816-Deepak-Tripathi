package org.cap.test;

import static org.junit.Assert.*;

import org.cap.demo.Calculate;
import org.junit.Ignore;
import org.junit.Test;

public class MyFirstTest {
	
	@Ignore
	@Test(timeout=10)
	public void test_runLoop() {
		Calculate calculate=new Calculate();
		calculate.runLoop();
	}
	

	@Test
	public void test_addNumber_method() {
		Calculate calculate=new Calculate();
		assertEquals(15,calculate.addNumber(5, 10));
	}

}
