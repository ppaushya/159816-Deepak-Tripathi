package org.lib.service;


import org.lib.bean.Users;
import org.lib.dao.ILoginDao;
import org.lib.dao.LoginDaoImpl;
import org.lib.exceptions.InvalidUserException;

import java.util.List;

import org.apache.log4j.Logger;
import org.lib.util.Utility;

public class LoginServiceImpl implements ILoginService{
	
	ILoginDao loginDao = new LoginDaoImpl();

	   public final static Logger logger=Logger.getLogger(LoginServiceImpl.class);
	
	
	   
	   
	   public LoginServiceImpl(ILoginDao loginDao) {
		super();
		this.loginDao = loginDao;
	}



	public void runMe(String parameter)
		{
			if(logger.isDebugEnabled())
			{
				logger.debug("This is debug: "+parameter);
			}
			
			if(logger.isInfoEnabled())
			{
				logger.info("This is info: "+parameter);
			}
			
			logger.warn("This is warn: "+parameter);
			logger.error("This is error: "+parameter);
			logger.fatal("This is fatal: "+parameter);
		}
	   
	   
	
	@Override
	public boolean validStudent(String userName, String password, int c) {
		
		if(Utility.isvaliduser(userName))
		{
				 
				 boolean turn = loginDao.validStudent(userName, password, c);
				
				return turn;
		}else
		{
		       logger.error("customer is invalid");	
				try {
					throw new InvalidUserException("details not in proper format..so account cant be created");
				} catch (InvalidUserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		return false;
	}
	@Override
	public boolean validLibrarian(String userNameLib, String passwordLib, int c) {
		
		if(Utility.isvaliduser(userNameLib))
		{
			boolean turn = loginDao.validLibrarian(userNameLib, passwordLib, c);
			return turn;
		}else
		{
	       logger.error("User is invalid");	
			try {
				throw new InvalidUserException("Details not in proper format..so  cant login");
			} catch (InvalidUserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	return false;
	}



	@Override
	public List<Users> getallusers() {
		// TODO Auto-generated method stub
		return loginDao.getallusers();
	}
	

}
