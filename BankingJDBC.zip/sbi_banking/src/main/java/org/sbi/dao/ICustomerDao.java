package org.sbi.dao;

import java.util.List;
import java.util.Set;

import org.sbi.model.Account;
import org.sbi.model.Customer;

public interface ICustomerDao {
	
	public  List<Customer> getAllCustomer();
	public Set<Account> getAllAccounts(int id);
	public void createCustomer(Customer customer);
    public void createaccounts(Customer customer,Account account);
}

