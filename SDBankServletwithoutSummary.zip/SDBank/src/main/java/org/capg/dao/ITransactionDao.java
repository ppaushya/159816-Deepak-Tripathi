package org.capg.dao;

import java.util.List;

import java.util.Map;
import org.capg.model.Account;
import org.capg.model.Transaction;

public interface ITransactionDao {

	public Transaction createTransactionOther(long acc, long acc1, double currentBal, Transaction transaction) ;
	public Transaction createTransaction(long acc, double currentBal, Transaction transaction);
	
}
