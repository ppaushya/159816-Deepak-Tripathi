package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao {

		
		@Override
		public Transaction createTransaction(long acc, double currentBal, Transaction transaction) {
			// TODO Auto-generated method stub
			String sql="insert into transaction(transactionDate, fromAccountNumber, toAccountNumber, amount, transactionType, currentBalance, description) values(?,?,?,?,?,?,?);";
			String sql1 = "select * from account";
			try(Connection connection=getConnection())
			{ 
				PreparedStatement pst=getConnection().prepareStatement(sql1);
			
				double openbal=0;
				double newBalance = 0;
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
					if(rs.getLong(1)==acc)
					{
						 openbal=rs.getDouble(5);
					}
				}
				if(transaction.getTransactionType().equals("Deposit")) {
					 newBalance = openbal + currentBal;
				}
				else if(transaction.getTransactionType().equals("Withdrawl")){
					newBalance = openbal - currentBal;
				}
				System.out.println(newBalance);
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
				statement.setLong(2, acc);
				statement.setLong(3, acc);
				statement.setDouble(4, transaction.getAmount());
				statement.setString(5, transaction.getTransactionType());
				statement.setDouble(6, newBalance);
				statement.setString(7, transaction.getDescription());
			
				int row=statement.executeUpdate();
				
				if(row>0)
					System.out.println(row+" row inserted successfully in Transactions table!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	
	@Override
	public Transaction createTransactionOther(long acc, long acc1, double currentBal, Transaction transaction) {
		// TODO Auto-generated method stub
		String sql="insert into transaction(transactionDate, fromAccountNumber, toAccountNumber, amount, transactionType, currentBalance, description) values(?,?,?,?,?,?,?);";
		String sql1 = "select * from account";
		
		
		
		try(Connection connection=getConnection())
		{ 
			PreparedStatement pst=getConnection().prepareStatement(sql1);
		
			double openbal=0;
			double newBalance = 0;
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				if(rs.getLong(1)==acc)
				{
					 openbal=rs.getDouble(5);
				}
			}
			
				 newBalance = openbal + currentBal;
			
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
			statement.setLong(2, acc);
			statement.setLong(3, acc1);
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getTransactionType());
			statement.setDouble(6, newBalance);
			statement.setString(7, transaction.getDescription());
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Transactions table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	

}
