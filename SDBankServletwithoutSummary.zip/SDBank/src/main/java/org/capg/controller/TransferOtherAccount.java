package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/TransferOtherAccount")
public class TransferOtherAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IAccountService loginService=new AccountServiceImpl();
		HttpSession session=request.getSession();
		
		String mail=session.getAttribute("emailId").toString();
		
		System.out.print(mail);
		
				List<Account> accounts=new ArrayList<>();
				accounts=loginService.getAllAccounts(mail);
				List<Account> accounts12=new ArrayList<>();
				accounts12=loginService.getAllToAccounts(mail);
				System.out.println(mail);
				
		
		PrintWriter out=response.getWriter();
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Insert title here</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<body>   \r\n" + 
				"    <form id=\"form1\" method=\"post\" action=\"./TransferOtherAccountPost\">  \r\n" + 
				"    <div>                \r\n" + 
				"    </div>   \r\n" + 
				"    <h2 align=\"center\"> Do Transaction:</h2>  \r\n" + 
				"    <table id=\"table1\"; cellspacing=\"5px\" cellpadding=\"5%\"; align=\"center\">  \r\n" + 
				"     \r\n" + 
				"     \r\n" + 
				"     <tr>  \r\n" + 
				"          <td>From Account: </td>\r\n" + 
				"          <td>\r\n" + 
				"<select name=\"fromAccount\">\r\n"   );  
		
			     for(Account account:accounts)
			     {
					out.println( "<option value=\""
							+ account.getAccountNumber()
							+ "\"> " 
							+ account.getAccountNumber() + " - " /*+ account.getAccountType() */
							+ "</option>\r\n" ); 
							
			     }
			
			    out.println("</select>\r\n" +
				"        </td>  \r\n" + 
				"       </tr> \r\n" + 
				"       \r\n" + 
				"        <tr>  \r\n" + 
				"          <td>To Account: </td>\r\n" + 
				"          <td>\r\n" + 
				"<select name=\"toAccount\">\r\n"   );  
				
			     for(Account account:accounts12)
			     {
					out.println( "<option value=\""
							+ account.getAccountNumber()
							+ "\"> " 
							+ account.getAccountNumber() + " - " /*+ account.getAccountType() */
							+ "</option>\r\n" ); 
							
			     }
			
			    out.println("</select>\r\n" +
				"        </td>  \r\n" + 
				"       </tr> \r\n" + 
				"         \r\n" + 
				"       	 \r\n" + 
				"      \r\n" + 
				"       <tr>  \r\n" + 
				"              <td >Amount to Transfer:</td>  \r\n" + 
				"              <td><input type=\"text\" name=\"Amount\" /></td>  \r\n" + 
				"       </tr>  \r\n" + 
				"       \r\n" + 
				"       <tr>  \r\n" + 
				"              <td >Description: </td>  \r\n" + 
				"              <td><input type=\"text\" name=\"Description\" /></td>  \r\n" + 
				"       </tr> \r\n" + 
				"      \r\n" + 
				"               \r\n" + 
				"        <tr>  \r\n" + 
				"        <td> <input type=\"submit\" name=\"TransferOtherAccountPost\" value=\"Do Transaction\" class=\"btnStyle\">  \r\n" + 
				"        </td>  \r\n" + 
				"        </tr>  \r\n" + 
				"</table>   \r\n" + 
				"    </form>  \r\n" + 
				"</body>  \r\n" + 
				"</body>\r\n" + 
				"</html>");
		
	
	}
		
}




/*
		Transaction transaction=new Transaction();
		transaction.setTransactionId(Utility.generateNumber());
		transaction.setTransactionDate(LocalDate.now());

		transaction.setTransactionType("Fund Transfer");

		transaction.setAmount(amt);
		transaction.setFromAccount(fromAcc);
		transaction.setToAccount(toAcc);
		transaction.setDescription("Amount "+amt+" is transfered to account number "+toAcc.getAccountNo()+
				" from account number "+fromAcc.getAccountNo());
		
		
		double currentBal,openingBal;
		openingBal=account.getOpeningBalance();
		currentBal=openingBal;

		List<Transaction> transactions= transactionServices.getAllTransactions(account);

		for(Transaction element:transactions)
		{
			if(element.getTransactionType().equals("Debit"))
				currentBal-=element.getAmount();
			else if(element.getTransactionType().equals("Credit"))
				currentBal+=element.getAmount();
			else if(element.getTransactionType().equals("Fund Transfer"))
			{
				if(element.getFromAccount()==null)
					currentBal+=element.getAmount();
				else
					currentBal-=element.getAmount();
			}
		}
	}

}*/
