package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Account;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.ITransactionService;
import org.capg.service.LoginServiceImpl;
import org.capg.service.TransactionServiceImpl;

/**
 * Servlet implementation class DepositWithdrawPost
 */
@WebServlet("/DepositWithdrawPost")
public class DepositWithdrawPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp) 
			throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		
		//Capture the data from View
		String accountNumber=request.getParameter("fromAccount").toString();
		String transactionType=request.getParameter("transactionType");
		String amount=request.getParameter("Amount");
		String description=request.getParameter("description");
		
		
	
		Transaction transaction=new Transaction();
		Account account = new Account();
		
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionType(transactionType);
		transaction.setAmount(Double.parseDouble(amount));
		
		Long acc = Long.parseLong(accountNumber);
		ITransactionService transactionServices = new TransactionServiceImpl();
		double currentBal;
		currentBal=transaction.getAmount();
		transaction.setDescription(description);
	
		System.out.println(currentBal);
		Transaction trans = transactionServices.createTransaction(acc, currentBal, transaction);
		if(trans!=null) {
			resp.sendRedirect("DepositWithdraw");
			System.out.println("Transaction Done.....");
		}
		else
			System.out.println("Transaction done Failed.....");
		
		
	}
}
