package org.cap.demo;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;


public class JDBC_implementation {
	
	public static void main(String[] args)
	{
	Connection connection = null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","India123");
		String sql = "create table employee12(empid int primary key, firstName varchar(25) not null,"
					+"lastName varchar(25), empdoj date, salary numeric(8,2))";
		Statement statement = connection.createStatement();
		boolean flag = statement.execute(sql);
		if(!flag)
		{
			System.out.println("Table Created Succesfully!");
		}
		}	catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				connection.close();
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
			
			
		}
	
	}
	
}
