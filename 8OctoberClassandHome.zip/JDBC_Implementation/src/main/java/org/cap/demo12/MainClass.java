package org.cap.demo12;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;


public class MainClass {
	
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		
		UserInteraction userInteraction=new UserInteraction();
		EmployeeDao employeeDao=new EmployeeDaoImpl();
		int option;
		String choice;
		do {
		System.out.println("1.Create Employee");
		System.out.println("2.Update Employee");
		System.out.println("3.Delete Employee");
		System.out.println("4.List All Employee");
		System.out.println("5.Find Employee");
		System.out.println("6.Call Stored Procedure");
		System.out.println("7.Bulk Operation");
		System.out.println("8.Exit");
		System.out.println("Enter your option:");
		option=scanner.nextInt();
			switch(option) {
			case 1:
				Employee employee=userInteraction.createEmployee();
				employeeDao.createEmployee(employee);
				break;
			case 2:
				int empId1=userInteraction.promptEmployeeID();
				String empfirstname=userInteraction.promptEmployeeFirstName();
				employeeDao.updateEmployee(empId1, empfirstname);
				break;
			case 3:
				int empId=userInteraction.promptEmployeeID();
				employeeDao.deleteEmployee(empId);
				break;
			case 4:
				List<Employee> employees= employeeDao.getAllEmployees();
				userInteraction.printAllEmployees(employees);
				break;
			case 5:
				int empId2=userInteraction.promptEmployeeID();
				employeeDao.findEmployee(empId2);
				break;
			case 6:
				int emplyId=userInteraction.promptEmployeeID();
				Employee employee2= employeeDao.callProcedure(emplyId);
				System.out.println(employee2);
				break;
			case 7:
				employeeDao.callBulkInsertion();
				break;
			case 8:
				System.exit(0);
			default:
				System.out.println("Sorry! Invalid Option!");
			}
			System.out.println("You wish to continue[y|n]:");
			choice=scanner.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		}

}
