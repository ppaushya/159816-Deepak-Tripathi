package org.cap.demo12;

import java.util.List;


public interface  EmployeeDao {
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	public void updateEmployee(int employeeId, String firstName);
	public void findEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	public Employee callProcedure(int employeeId);
	public void callBulkInsertion();

}
