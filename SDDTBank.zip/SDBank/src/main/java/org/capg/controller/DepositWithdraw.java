package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/DepositWithdraw")
public class DepositWithdraw extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>Insert title here</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<body>   \r\n" + 
				"    <form id=\"form1\" runat=\"server\">  \r\n" + 
				"    <div>                \r\n" + 
				"    </div>   \r\n" + 
				"    <h2 align=\"center\"> DO TRANSACTION</h2>  \r\n" + 
				"    <table id=\"table1\"; cellspacing=\"5px\" cellpadding=\"5%\"; align=\"center\">  \r\n" + 
				"     \r\n" + 
				"     \r\n" + 
				"     <tr>  \r\n" + 
				"          <td>Choose Account: </td>\r\n" + 
				"          <td>\r\n" + 
				"        <select name=\"cars\">  \r\n" + 
				"            <option value=\"Rupees\">Rupees</option>  \r\n" + 
				"            <option value=\"Euro\">Euro</option>  \r\n" + 
				"            <option value=\"US Dollar\" selected=\"selected\">US Dollar</option>  \r\n" + 
				"            </select>                   \r\n" + 
				"        </td>  \r\n" + 
				"       </tr> \r\n" + 
				"        \r\n" + 
				"          <tr> \r\n" + 
				"          <td>Type of transaction </td>\r\n" + 
				"          <td>\r\n" + 
				"        <input type=\"radio\" name=\"vehicle\" value=\"Deposit\" /> Deposit  \r\n" + 
				"        <input type=\"radio\" name=\"vehicle\" value=\"Withdraw\" />Withdraw \r\n" + 
				"        </td>  \r\n" + 
				"       	</tr> \r\n" + 
				"       	 \r\n" + 
				"      \r\n" + 
				"       <tr>  \r\n" + 
				"              <td >Amount</td>  \r\n" + 
				"              <td><input type=\"text\" name=\"Amount\" /></td>  \r\n" + 
				"       </tr>  \r\n" + 
				"       <tr>  \r\n" + 
				"              <td >Description</td>  \r\n" + 
				"              <td><input type=\"text\" name=\"Description\" /></td>  \r\n" + 
				"       </tr>  \r\n" + 
				"      \r\n" + 
				"               \r\n" + 
				"        <tr>  \r\n" + 
				"        <td> <input type=\"button\" value=\"Do Transaction\" align=\"right\"/>  \r\n" + 
				"        </td>  \r\n" + 
				"        </tr>  \r\n" + 
				"</table>   \r\n" + 
				"    </form>  \r\n" + 
				"</body>  \r\n" + 
				"</body>\r\n" + 
				"</html>");
		
	
	}
		
}

