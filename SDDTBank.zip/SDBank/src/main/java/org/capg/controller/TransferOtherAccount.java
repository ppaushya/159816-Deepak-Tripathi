package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Transaction;
import org.capg.util.Utility;

/**
 * Servlet implementation class TransferOtherAccount
 */
@WebServlet("/TransferOtherAccount")
public class TransferOtherAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public TransferOtherAccount() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Transaction transaction=new Transaction();
		transaction.setTransactionId(Utility.generateNumber());
		transaction.setTransactionDate(LocalDate.now());

		transaction.setTransactionType("Fund Transfer");

		transaction.setAmount(amt);
		transaction.setFromAccount(fromAcc);
		transaction.setToAccount(toAcc);
		transaction.setDescription("Amount "+amt+" is transfered to account number "+toAcc.getAccountNo()+
				" from account number "+fromAcc.getAccountNo());
		
		
		double currentBal,openingBal;
		openingBal=account.getOpeningBalance();
		currentBal=openingBal;

		List<Transaction> transactions= transactionServices.getAllTransactions(account);

		for(Transaction element:transactions)
		{
			if(element.getTransactionType().equals("Debit"))
				currentBal-=element.getAmount();
			else if(element.getTransactionType().equals("Credit"))
				currentBal+=element.getAmount();
			else if(element.getTransactionType().equals("Fund Transfer"))
			{
				if(element.getFromAccount()==null)
					currentBal+=element.getAmount();
				else
					currentBal-=element.getAmount();
			}
		}
	}

}
