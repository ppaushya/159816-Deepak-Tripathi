package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao	{
	
	
	@Override
	public List<Account> getAccountsOfCustomer(int custId)
	{
		List<Account> accounts=new ArrayList<>();
		String str="select * from account where customerId=?;";
		
		try(Connection connection=getConnection())
		{
			Account account=new Account();
			PreparedStatement statement=connection.prepareStatement(str);
			statement.setInt(1, custId);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				
				AccountType accType=AccountType.SAVINGS;
				
					account.setAccountNumber(resultSet.getLong(2));
					account.setAccountType(accType.valueOf(resultSet.getString(3).toUpperCase()));
					account.setOpeningDate(resultSet.getDate(4).toLocalDate());
					account.setOpeningBalance(resultSet.getDouble(5));
					account.setDescription(resultSet.getString(6));
					accounts.add(account);
			
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accounts;
	}
	
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
