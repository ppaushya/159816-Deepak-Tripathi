package org.capg.dao;

import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;

public interface IAccountDao {
	
	public List<Account> getAccountsOfCustomer(int custId);
	

}
