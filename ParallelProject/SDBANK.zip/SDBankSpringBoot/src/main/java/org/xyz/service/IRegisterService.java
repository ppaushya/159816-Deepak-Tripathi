package org.xyz.service;

import org.xyz.model.CustomerBean;

public interface IRegisterService {

	public boolean registerCustomer(CustomerBean customerBean);
}
