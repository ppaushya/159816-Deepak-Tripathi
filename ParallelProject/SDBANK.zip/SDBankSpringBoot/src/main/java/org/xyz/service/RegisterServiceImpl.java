package org.xyz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xyz.dao.IRegisterDao;
import org.xyz.model.CustomerBean;

@Service("registerService")
public class RegisterServiceImpl implements IRegisterService{
	
	@Autowired
	IRegisterDao registerDao;
	
	@Override
	public boolean registerCustomer(CustomerBean customerBean) {
		registerDao.save(customerBean);
		return true;
	}
}
