package org.capg.service;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer isFound(int customerId);

	public void setAccountDetails(Customer customer,Account account);
}
