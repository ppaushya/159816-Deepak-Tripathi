import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ILogin } from '../../app/login/login';
import { Observable } from 'rxjs/Observable';
import { ICustomer } from '../../app/register/customer';
import { Message } from '../../app/message/message';

@Injectable()
export class RegisterService{

    private _registerUrl = "http://localhost:8084/api/v1/register";

    constructor(private http: HttpClient){

    }

    register(customer:ICustomer): Observable<Message>{
        return this.http.post<Message>(this._registerUrl,customer,{});
    }
}