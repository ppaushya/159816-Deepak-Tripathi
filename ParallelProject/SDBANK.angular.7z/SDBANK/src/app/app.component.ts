import { Component } from '@angular/core';
import { AccountService } from '../api/account/account.service';
import { TransactionService } from '../api/transaction/transaction.service';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  //providers: []
})
export class AppComponent {
  pagetitle='SDDT BANK Net Banking'
}
