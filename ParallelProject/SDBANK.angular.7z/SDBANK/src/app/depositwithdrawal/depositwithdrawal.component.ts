import {Component, OnInit} from '@angular/core';
import { Account } from '../account/account';
import { AccountService } from '../../api/account/account.service';
import { LoginService } from '../../api/login/login.service';
import { Transaction } from '../transaction/transaction';
import { TransactionService } from '../../api/transaction/transaction.service';

@Component({
    selector:'pm-depositwithdrawal',
    templateUrl: './depositwithdrawal.component.html',
    providers: [AccountService,TransactionService],
    styleUrls: ['./depositwithdrawal.component.css']
})

export class DepositWithdrawalComponent implements OnInit{
    pageTitle: string='Deposit/Withdrawal';
    errorMessage: string;
    transaction: Transaction = new Transaction();

    accounts:Account[] = [];
    
    message: string;
    showMessage: boolean = false;

    constructor(private _accountService: AccountService,private _transactionService: TransactionService,private loginService:LoginService){
        
    }

    ngOnInit(): void {
        console.log("In OnInit");
        this._accountService.getAccounts(this.loginService.getCustomer().customerId)
            .subscribe(
                accounts => {
                    this.accounts = accounts;
                },
                error => this.errorMessage = <any>error
            );
    }

    doTransaction():void{
        console.log(this.transaction);
        this._transactionService.doTransaction(this.transaction)
        .subscribe(
            message => {
                console.log(message);
                if(message['success']==true){
                    this.showMessage = true;
                    this.message="Transaction successful";
                }
            },
            error => this.errorMessage = <any>error
        );
    }
}