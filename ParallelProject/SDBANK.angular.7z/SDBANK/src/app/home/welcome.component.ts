import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'pm-home',
    templateUrl: './welcome.component.html',
    styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit{
    public pageTitle: string = 'Welcome';

    constructor(private router: Router){
        
    }
    
    ngOnInit(): void {
        console.log("In OnInit");
        
        this.router.navigate(['/login']);
    }
}
