export class ILogin{
    username:string;
    password:string;
}