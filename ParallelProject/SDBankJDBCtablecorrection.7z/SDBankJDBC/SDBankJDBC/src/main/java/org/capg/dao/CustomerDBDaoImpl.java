package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDBDaoImpl implements ICustomerDao {

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		
		List<Customer> lst=new ArrayList<>();
		String str="select * from customers;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Customer customer=new Customer();
				Address address=new Address();
				Set<Account> accounts=new HashSet<>();
				Account account=new Account();
				AccountType accType=AccountType.SAVINGS;
				
				String strAddress="select * from address where customerId="+resultSet.getInt(1)+";";

				PreparedStatement statement1=connection.prepareStatement(strAddress);
				ResultSet resultSet1= statement1.executeQuery();
				
				while(resultSet1.next())
				{
					address.setAddressLine1(resultSet1.getString(2));
					address.setAddressLine2(resultSet1.getString(3));
					address.setCity(resultSet1.getString(4));
					address.setState(resultSet1.getString(5));
					address.setPinCode(resultSet1.getLong(6));
				}
				
				String strAccount="select * from accounts where customerID="+resultSet.getInt(1)+";";
				PreparedStatement statement2=connection.prepareStatement(strAccount);
				ResultSet resultSet2= statement2.executeQuery();
				
				while(resultSet2.next())
				{
					account.setAccountNo(resultSet2.getLong(2));
					account.setAccountType(accType.valueOf(resultSet2.getString(3).toUpperCase()));
					account.setOpeningDate(resultSet2.getDate(4).toLocalDate());
					account.setOpeningBalance(resultSet2.getDouble(5));
					account.setDescription(resultSet2.getString(6));
					accounts.add(account);
				}
				
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setEmailId(resultSet.getString(4));
				customer.setMobile(resultSet.getString(5));
				customer.setDateOfBirth(resultSet.getDate(6).toLocalDate());
				customer.setAddress(address);
				customer.setAccounts(accounts);
				lst.add(customer);
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lst;
		
	}

	@Override
	public void createCustomer(Customer customer) {
		int customerId=0;
		boolean flag=false;
	String sql="insert into customers(firstName,lastName, emailId,mobile,dob)"+
						" values(?,?,?,?,?)";
		
	try(PreparedStatement pst=getConnection().prepareStatement(sql)) {
			
		
		pst.setString(1, customer.getFirstName());
		pst.setString(2, customer.getLastName());
		pst.setString(3, customer.getEmailId());
		pst.setString(4,customer.getMobile());
		pst.setDate(5, Date.valueOf(customer.getDateOfBirth()));
		
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
		if(flag) {
			String sqlMax="select max(customerId) from customer";
			try(PreparedStatement pst1=getConnection().prepareStatement(sqlMax)) {
				ResultSet rs= pst1.executeQuery();
				if(rs.next())
					customerId=rs.getInt(1);
				
				
				String sqlAdd="insert into address(addressline1,addressline2,city,state,pincode,customerId) values(?,?,?,?,?,?)";
				
				try(PreparedStatement pst2=getConnection().prepareStatement(sqlAdd)) {
					pst2.setString(1, customer.getAddress().getAddressLine1());
					pst2.setString(2, customer.getAddress().getAddressLine2());
					pst2.setString(3, customer.getAddress().getCity());
					pst2.setString(4, customer.getAddress().getState());
					pst2.setLong(5, customer.getAddress().getPinCode());
					pst2.setInt(6, customerId);
					
					int count1=pst2.executeUpdate();
					if(count1>0)
						flag=true;
					else
						flag=false;
					
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else {
			flag=false;
		}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
