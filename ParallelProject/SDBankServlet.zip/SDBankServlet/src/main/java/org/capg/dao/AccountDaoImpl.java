package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;

public class AccountDaoImpl implements IAccountDao	{
	
	
	public List<Account> getAllAccounts(String mailid) {
		// TODO Auto-generated method stub
		
		List<Account> accounts=new ArrayList<>();
		int custid=0;
		String sql="select * from account";
		String sql1="select * from customer";
		
		try(PreparedStatement pst=getConnection().prepareStatement(sql)) {
			PreparedStatement pst1=getConnection().prepareStatement(sql1);
			
			ResultSet res=pst1.executeQuery();
			
			while(res.next())
			{
				if(res.getString(5).compareTo(mailid)==0)
				{
					custid=res.getInt(1);
					System.out.println(custid);
				}
			}
			
			
			ResultSet res1=pst.executeQuery();
			
			while(res1.next())
			{
				if(res1.getInt(2)==custid)
				{
					Account acc=new Account();
					acc.setAccountNumber(res1.getInt(1));
					//acc.setAccountType(res1.getString(2));
				//	acc.setOpeningDate(res1.getDate(3).toLocalDate());
					//acc.setOpeningBalance(res.getDouble(4));
					//acc.setDescription(res.getString(5));
				
					System.out.println(acc);
					accounts.add(acc);
				}
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return accounts;
		
	}
	

	
	
	public List<Account> getAllToAccounts(String mailid) {
		// TODO Auto-generated method stub
		
		List<Account> accounts=new ArrayList<>();
		int custid=0;
		String sql="select * from account where customerId <> ?";
		String sql1="select * from customer";
		
		try(PreparedStatement pst=getConnection().prepareStatement(sql)) {
			PreparedStatement pst1=getConnection().prepareStatement(sql1);
			
			ResultSet res=pst1.executeQuery();
			
			while(res.next())
			{
				if(res.getString(5).compareTo(mailid)==0)
				{
					custid=res.getInt(1);
					System.out.println(custid);
				}
			}
			
			pst.setInt(1, custid);
			ResultSet res1=pst.executeQuery();
			
			while(res1.next())
			{
				
					Account acc=new Account();
					acc.setAccountNumber(res1.getInt(1));
					//acc.setAccountType(res1.getString(2));
				//	acc.setOpeningDate(res1.getDate(3).toLocalDate());
					//acc.setOpeningBalance(res.getDouble(4));
					//acc.setDescription(res.getString(5));
				
					System.out.println(acc);
					accounts.add(acc);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		return accounts;
		
	}
	
	
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
