package org.capg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao {

		
		@Override
		public Transaction createTransaction(long acc, double currentBal, Transaction transaction) {
			// TODO Auto-generated method stub
			String sql="insert into transaction(transactionDate, fromAccountNumber, toAccountNumber, amount, transactionType, currentBalance, description) values(?,?,?,?,?,?,?);";
			String sql1 = "select * from account";
			try(Connection connection=getConnection())
			{ 
				PreparedStatement pst=getConnection().prepareStatement(sql1);
			
				double openbal=0;
				double newBalance = 0;
				ResultSet rs=pst.executeQuery();
				
				while(rs.next())
				{
					if(rs.getLong(1)==acc)
					{
						 openbal=rs.getDouble(5);
					}
				}
				if(transaction.getTransactionType().equals("Deposit")) {
					 newBalance = openbal + currentBal;
				}
				else if(transaction.getTransactionType().equals("Withdrawl")){
					newBalance = openbal - currentBal;
				}
				System.out.println(newBalance);
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
				statement.setLong(2, acc);
				statement.setLong(3, acc);
				statement.setDouble(4, transaction.getAmount());
				statement.setString(5, transaction.getTransactionType());
				statement.setDouble(6, newBalance);
				statement.setString(7, transaction.getDescription());
			
				int row=statement.executeUpdate();
				
				if(row>0)
					System.out.println(row+" row inserted successfully in Transactions table!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	
	@Override
	public Transaction createTransactionOther(long acc, long acc1, double currentBal, Transaction transaction) {
		// TODO Auto-generated method stub
		String sql="insert into transaction(transactionDate, fromAccountNumber, toAccountNumber, amount, transactionType, currentBalance, description) values(?,?,?,?,?,?,?);";
		String sql1 = "select * from account";
		
		
		
		try(Connection connection=getConnection())
		{ 
			PreparedStatement pst=getConnection().prepareStatement(sql1);
		
			double openbal=0;
			double newBalance = 0;
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				if(rs.getLong(1)==acc)
				{
					 openbal=rs.getDouble(5);
				}
			}
			
				 newBalance = openbal + currentBal;
			
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
			statement.setLong(2, acc);
			statement.setLong(3, acc1);
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getTransactionType());
			statement.setDouble(6, newBalance);
			statement.setString(7, transaction.getDescription());
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Transactions table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Set<Transaction> getAllTransactionsOfCustomer(long customerId) {
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate,t.fromAccountNumber, t.toAccountNumber, t.amount, t.transactionType,t.currentBalance, t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber"
					+ " and (a1.customerId = ? or a2.customerId=?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customerId);
			statement.setLong(2, customerId);
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfCustomerInDateRange(long customerId,LocalDate fromDate,LocalDate toDate){
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate, t.fromAccountNumber, t.toAccountNumber, t.amount, t.transactionType, t.currentBalance,t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber"
					+ " and (a1.customerId = ? or a2.customerId=?)"
					+ " and (t.transactionDate between ? and ?)"
					+ " order by t.transactionId desc";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customerId);
			statement.setLong(2, customerId);
			statement.setDate(3, Date.valueOf(fromDate));
			statement.setDate(4, Date.valueOf(toDate));
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfAccount(long accountNumber) {
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate, t.amount, t.transactionType, t.fromAccountNumber, t.toAccountNumber, t.currentBalance, t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber"
					+ " and (fromAccountNumber=? or toAccountNumber=?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, accountNumber);
			statement.setLong(2, accountNumber);
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	private Set<Transaction> getAllTransactionsFromCursor(ResultSet resultSet) throws SQLException {
		Set<Transaction> transactions = new LinkedHashSet<>();
		
		while(resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setTransactionId(resultSet.getLong("t.transactionId"));
				transaction.setTransactionDate(resultSet.getDate("t.transactionDate").toLocalDate());
				
				Account fromAccount = new Account();
				fromAccount.setAccountNumber(resultSet.getLong("a1.accountNumber"));
				fromAccount.setAccountType(AccountType.valueOf(resultSet.getString("a1.accountType")));
				fromAccount.setOpeningDate(resultSet.getDate("a1.openingDate").toLocalDate());
				fromAccount.setOpeningBalance(resultSet.getDouble("a1.openingBalance"));
				fromAccount.setDescription(resultSet.getString("a1.description"));

				Account toAccount = new Account();
				toAccount.setAccountNumber(resultSet.getLong("a2.accountNumber"));
				toAccount.setAccountType(AccountType.valueOf(resultSet.getString("a2.accountType")));
				toAccount.setOpeningDate(resultSet.getDate("a2.openingDate").toLocalDate());
				toAccount.setOpeningBalance(resultSet.getDouble("a2.openingBalance"));
				toAccount.setDescription(resultSet.getString("a2.description"));


				transaction.setFromAccount(resultSet.getLong("t.fromAccountNumber"));
				transaction.setToAccount(resultSet.getLong("t.toAccountNumber"));
				transaction.setAmount(resultSet.getDouble("t.amount"));
				transaction.setTransactionType(resultSet.getString("t.transactionType"));
				System.out.println(resultSet.getDouble("t.currentBalance"));
				transaction.setCurrentBalance(resultSet.getDouble("t.currentBalance"));
				transaction.setDescription(resultSet.getString("t.description"));
				
				transactions.add(transaction);
			}
		return transactions;
	}
	

}
