package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Account;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.ITransactionService;
import org.capg.service.LoginServiceImpl;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/TransferOtherAccountPost")
public class TransferOtherAccountPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public TransferOtherAccountPost() {
        super();
        // TODO Auto-generated constructor stub
    }



	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		
ILoginService loginService=new LoginServiceImpl();
		
		//Capture the data from View
		String accountNumber=request.getParameter("fromAccount").toString();
		String accountNumber1=request.getParameter("toAccount").toString();
		String transactionType="FundTransfer";
		String amount=request.getParameter("Amount");
		String description=request.getParameter("Description");
		
		
	
		Transaction transaction=new Transaction();
		Account account = new Account();
		
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionType(transactionType);
		transaction.setAmount(Double.parseDouble(amount));
		
		Long acc = Long.parseLong(accountNumber);
		Long acc1 = Long.parseLong(accountNumber1);
		ITransactionService transactionServices = new TransactionServiceImpl();
		double currentBal,openingBal;
		openingBal=account.getOpeningBalance();
		currentBal=openingBal;
		System.out.println(currentBal);
		
			
				currentBal=transaction.getAmount();
			
		
		
		System.out.println(currentBal);
		transaction.setCurrentBalance(currentBal);
		transaction.setDescription(description);
	
		
		Transaction trans = transactionServices.createTransactionOther(acc, acc1, currentBal, transaction);
		if(trans==null) {
			resp.sendRedirect("TransferOtherAccount");
			System.out.println("Transaction Done.....");
		}
		else
			System.out.println("Transaction done Failed.....");
		
		
	}
		
}


