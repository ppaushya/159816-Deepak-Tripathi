package org.capg.service;

import java.time.LocalDate;
import java.util.List;

import java.util.Map;
import java.util.Set;

import org.capg.dao.ITransactionDao;
import org.capg.dao.TransactionDaoImpl;
import org.capg.model.Account;
import org.capg.model.Transaction;

public class TransactionServiceImpl implements ITransactionService {

	
	private ITransactionDao transDao=new TransactionDaoImpl();
	
	@Override
	public Transaction createTransaction(long acc, double currentBal,Transaction transaction) {
		// TODO Auto-generated method stub
		return transDao.createTransaction(acc,currentBal,transaction);
	}

	@Override
	public Transaction createTransactionOther(long acc, long acc1, double currentBal, Transaction transaction)  {
		// TODO Auto-generated method stub
		return transDao.createTransactionOther(acc, acc1, currentBal,transaction);
	}

	@Override
	public Set<Transaction> getAllTransactionsOfCustomer(long customerId) {
		return transDao.getAllTransactionsOfCustomer(customerId);
	}
	
	@Override
	public Set<Transaction> getAllTransactionsOfCustomerInDateRange(long customerId,LocalDate fromDate,LocalDate toDate){
		return transDao.getAllTransactionsOfCustomerInDateRange(customerId,fromDate,toDate);
	}

	@Override
	public Set<Transaction> getAllTransactionsOfAccount(long accountNumber) {
		return transDao.getAllTransactionsOfAccount(accountNumber);
	}

	
}
