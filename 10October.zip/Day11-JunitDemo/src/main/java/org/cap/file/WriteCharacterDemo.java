package org.cap.file;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharacterDemo {
	
	public static void main(String[] args)
	{
		File file = new File("C:\\demo\\filedemo\\sample.txt");
		int ch = 0;
		
		String greetings = "Do not sleep in my class";
		
		try (FileWriter writer = new FileWriter(file)){
			writer.write(greetings);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
