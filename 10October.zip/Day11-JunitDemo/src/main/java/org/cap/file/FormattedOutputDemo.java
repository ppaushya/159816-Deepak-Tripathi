package org.cap.file;

public class FormattedOutputDemo {
	
	
}
