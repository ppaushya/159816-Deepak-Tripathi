package org.cap.file;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReverseFile {
	
	public static void main(String[] args)
	{
		File file = new File("C:\\demo\\filedemo\\myTextfile.txt");
		int ch = 0;
		int[] n = new int[10];
		int i=0;
		try (FileReader reader = new FileReader(file)){
			do {
				ch = reader.read();
				n[i] = ch;
				i=i+1;
			}while(ch!=-1);
			
			for(int j=i-2;j>=0;j--)
			{
				System.out.println((char)n[j]);
			}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
			
		} 
	

}
