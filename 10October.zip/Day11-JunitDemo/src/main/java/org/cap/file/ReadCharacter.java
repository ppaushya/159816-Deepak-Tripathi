package org.cap.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadCharacter {
	
	public static void main(String[] args)
	{
		File file = new File("C:\\demo\\filedemo\\mytext.txt");
		int ch = 0;
		try (FileReader reader = new FileReader(file)){
			do {
				ch = reader.read();
				System.out.print((char)ch);
			}while(ch!=-1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
			
		} 
		
		
	}


