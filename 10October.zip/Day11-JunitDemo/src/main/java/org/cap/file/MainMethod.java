package org.cap.file;

import java.io.File;
import java.io.IOException;

public class MainMethod {
	
	public static void main(String[] args)
	{
		File file = new File("C:\\demo\\filedemo\\mytext.txt");
		file.delete();
		if(file.isFile()) {
		if(file.exists())
		{
			System.out.println("Readable:" + file.canRead());
			System.out.println("Writable:" + file.canWrite());
			System.out.println("Executable:" + file.canExecute());
			System.out.println("path:" + file.getAbsolutePath());
		}
		else
		{
			System.out.println("No file exists");
		}
	}else if(file.isDirectory())
		{
			String[] names = file.list();
		}
	else {
		System.out.println("No File or Direcory Exist");
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
		System.out.println("FreeSpace: "+ file.getFreeSpace());
		System.out.println("TotalSpace: "+ file.getTotalSpace());
		System.out.println("UsedSpace: "+ file.getUsableSpace());

}
}
