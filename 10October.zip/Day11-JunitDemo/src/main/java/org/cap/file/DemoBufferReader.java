package org.cap.file;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;

public interface DemoBufferReader {
	
	public static void main(String[] args)
	{
		File file = new File("C:\\demo\\filedemo\\myTextfile.txt");
		
		try (FileInputStream in = new FileInputStream(file);
				BufferedInputStream inputStream = new BufferedInputStream(in)) {
			
			
			/*int mybyte = inputStream.read();
			while(mybyte!=-1)
			{
				System.out.println((char)mybyte);
				mybyte = inputStream.read();
			}*/
			
			byte[] arr = new byte[100];
			/*FilterInputStream intputStream;
			int ch[] = intputStream.read(arr);*/
				for(byte ch:arr)
				{
					System.out.println((char)ch);
				}
				
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
