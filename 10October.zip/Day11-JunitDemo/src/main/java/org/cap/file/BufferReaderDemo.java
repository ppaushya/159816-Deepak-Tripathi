package org.cap.file;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferReaderDemo {

	public static void main(String[] args)
	{
		FileReader in;
		try{
			in = new FileReader("C:\\demo\\filedemo\\myTextfile.txt");
			BufferedReader reader = new BufferedReader(in);
			
			String line = reader.readLine();
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
