package org.cap.demo;

import java.util.Date;
import java.util.Scanner;

public class Address{
	
	private String streetName;
	private String area;
	private String city;
	private String state;
	
	
	Scanner KB=new Scanner(System.in);
	
	public void Addressget()
	{
		System.out.print("Enter Street Name: ");
		streetName=KB.next();
		System.out.print("Enter Area: ");
		area=KB.next();
		System.out.print("Enter City: ");
		city=KB.next();
		System.out.print("Enter State: ");
		state=KB.next();
		
	}
	
	public void AddressShow()
	{
		System.out.print(streetName);
		System.out.println(area);
		System.out.println(city);
		System.out.println(state);
	}
	
	
}