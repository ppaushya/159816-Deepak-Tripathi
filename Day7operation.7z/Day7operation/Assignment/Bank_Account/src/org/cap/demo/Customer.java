package org.cap.demo;

import java.util.Scanner;

public class Customer extends Address
{
	int customerId;
	private String name;
	private String mobileNo;
	private String emailId;

	Scanner KB=new Scanner(System.in);
	
	//method to open an account
	public void getCustomer()
	{ 
		System.out.print("Enter Customer Id: ");
		customerId=KB.nextInt();
		System.out.print("Enter Name: ");
		name=KB.next();
		System.out.print("Enter Address: ");
		Addressget();
		System.out.print("Enter Mobile Number: ");
		name=KB.next();
		System.out.print("Enter Email Id: ");
		name=KB.next();
	}

	public void CustomerShow()
	{
		System.out.print(customerId);
		System.out.println(name);
		AddressShow();
		System.out.println(mobileNo);
		System.out.println(emailId);
		
	}
}
